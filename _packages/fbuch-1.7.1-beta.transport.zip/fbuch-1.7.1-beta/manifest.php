<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5b8b24400fb754ef8cdb3c58c307f7ec',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/b69312c722ffb4b7230e64e62c58cb58.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b5ad704e07af030f5157de4f6a60069',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/988d3b3220ff785b540f5f37044a8184.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'beaf5355d2faf5003f55cacab3b671d1',
      'native_key' => NULL,
      'filename' => 'modCategory/86fd076936eead57e6eb9768074439a8.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '55c23d70b99a33a639aff6e6e8a03d98',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/4188974ef9cb6c4fb9b72cad806610a1.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b614d0bb6303808009a99d993cb23222',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/e1d794382787d1af42f485e1cec8d359.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ac7d8ae0105dc27fc470019db71fbc4b',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/4dae9cbcb2ba728b78f8c283b5302436.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2bc586ed823bf11f79106cd717aab4df',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/1238f9fcd4603f98a868fa58237a30b8.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9fa5b2119323e768a722141399a9a757',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/4afca9a777bf4d31ca70b5e417f505bb.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);