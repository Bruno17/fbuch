<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '85657d487b85b8e09f4c3d43c9d4ca4d',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/fa2a0234d3b36285daf22aa75b226b5d.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '530fc43ed2df1bb81d831e9c870f7f9d',
      'native_key' => NULL,
      'filename' => 'modCategory/f9cca5bc44bc701c48b91bdf8a153ab9.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);