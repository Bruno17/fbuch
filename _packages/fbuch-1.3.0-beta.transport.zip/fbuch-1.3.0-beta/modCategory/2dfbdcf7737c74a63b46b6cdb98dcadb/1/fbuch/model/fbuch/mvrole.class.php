<?php
class mvRole extends xPDOSimpleObject {}