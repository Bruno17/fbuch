<?php
require_once (dirname(__DIR__) . '/mvmemberfilter.class.php');
class mvMemberFilter_mysql extends mvMemberFilter {}