<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '71cf2c89c8f14d2da418ac1003452518',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/8a9d5bb65271277e3a30a95aed0967a0.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '358a6f872ba0ca2a47246888ccfd2c86',
      'native_key' => NULL,
      'filename' => 'modCategory/2dfbdcf7737c74a63b46b6cdb98dcadb.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);