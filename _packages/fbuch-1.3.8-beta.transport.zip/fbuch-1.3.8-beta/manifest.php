<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6c9c108c7327477f1b5ae42811872a06',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/b7df00621c6a36241f60fbda233db30d.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '571aa3983e2598202d83e2bf3fc39474',
      'native_key' => NULL,
      'filename' => 'modCategory/cdc981af953f2ee1e9bfb57b9846d5cf.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);