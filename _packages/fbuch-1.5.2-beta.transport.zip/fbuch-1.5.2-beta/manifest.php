<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5e3fe80ebe4c3fd6282837b4697dec0b',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/ced712c98eb21ae118637c9245fa8995.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a23448e83ca667ac9daed372c6481c53',
      'native_key' => NULL,
      'filename' => 'modCategory/dae06bbf3fb0cf69534a396e0ec8c46e.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b5a927380ed32bc05f9f49a9cd605664',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/a923c0f0d9ada57c82129f3031daddd7.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '588021ab69cd9baaa4a2a07a50d314f8',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/5db5437e438f2eb47e1f9fda419e6f2e.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '94bb6741c100371bcbf813d4144c0922',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/5496bc42bde4f24346211a110c4fdf82.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '860cf380c5deb36c46e5a42e7c67f248',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/70ed4ba00a208863ac1aabcf1634ced9.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e78975143802ac146d319847e01dc65b',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/8ec5171d71e8fdad5cbc67c05030b4ae.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);