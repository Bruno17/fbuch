<?php
class mvMailLogRecipient extends xPDOSimpleObject {}