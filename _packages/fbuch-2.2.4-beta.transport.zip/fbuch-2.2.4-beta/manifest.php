<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2da6b2402c8acf53386f32c99866864c',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/7f8ef8f21a7563d493e4d2a2434f21d2.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f721e9c5546a147c3fba0a7c8ae49fa0',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/693fa6a439799b208cb35e399a383af5.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e0b8f585e7df9ef8dcbdd45b9b8a5199',
      'native_key' => NULL,
      'filename' => 'modCategory/67c28567c8b522484f44e377c7eeb4df.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7ad84602edda8dea333c619db2b457da',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/0366022503e5f4c9b22f299e2114b4c5.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1fec7461462643e8353f92499840f21c',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/0d8f9b302f7847b7be6b7f63e118f7c6.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e5d490a363de04f3ef0d27edb3e4be1b',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/9cd6d8e21ec8579f10e89a642bacebce.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'eab712768cc138d4f2e75a3a139254ac',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/c5c591f968128d26bb48876ad31a65b8.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '95133cfa226c871e11c8739b40fae3bf',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/aa0db8c3c6ca894512d87c6106e09bef.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);