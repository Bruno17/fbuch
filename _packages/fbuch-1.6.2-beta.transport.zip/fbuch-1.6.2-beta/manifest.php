<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0eaf8315b566128c01476207593a69f7',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/e4ff9df94820593cfa57d92437d82354.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd8c020c6d2e4113bf0fcecaee4a4cfec',
      'native_key' => NULL,
      'filename' => 'modCategory/f9f5fb924cb0dec3233b33101b0aff45.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8ff8a243d98b7fbea2db5743943b51e2',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/c9c7b19729431077ad13a82ce8b167cc.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4a8f5242dcdc701204dd8b8491d371cb',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/f7fa788fe965369db993b40dbc9419a0.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fd734d6dc12f2fa9f805c61ee6b93ba0',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/2471fe6901a794826c8dc3c15d200741.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ed102113cd86a5d2df2f7d3048017cc7',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/c3dee0e93d8172d4413b1e728b617789.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6eb80229b2ffcf4b8e10f8376f8b16b1',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/a3b93721a0a525f1e358cbc98591d22c.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);