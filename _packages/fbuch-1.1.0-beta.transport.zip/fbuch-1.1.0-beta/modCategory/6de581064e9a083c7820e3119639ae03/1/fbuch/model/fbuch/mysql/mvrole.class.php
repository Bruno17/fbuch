<?php
require_once (dirname(__DIR__) . '/mvrole.class.php');
class mvRole_mysql extends mvRole {}