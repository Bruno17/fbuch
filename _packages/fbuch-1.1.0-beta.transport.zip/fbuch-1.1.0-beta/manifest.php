<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9543eca1fd00908c3a92c7194d7efe8a',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/e9a82ddde004b6ca167c43fbb59193f2.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3a6b36e32ad263622bf227aaafac0b5c',
      'native_key' => NULL,
      'filename' => 'modCategory/6de581064e9a083c7820e3119639ae03.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);