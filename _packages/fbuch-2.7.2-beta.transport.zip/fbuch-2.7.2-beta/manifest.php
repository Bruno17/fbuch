<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7b536e6706be4063adf37f4da36fd2ab',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/ec1a48639924288bf3076f37ab96af66.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14e714e2b3b0fc4cf76440cc505f8586',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/302070d3c20609970b6d633f2ed70511.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1bfc431296be0c9d8cdc8afa6a6a085d',
      'native_key' => NULL,
      'filename' => 'modCategory/d76dce0c3a1490f88ef5f33d036ba710.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f417ccb8b01dff9bcd5b184917f94092',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/1586a2e4a49fc91a79a04b014c260788.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '175fb7d87c4754c206b96b847fb54cf3',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/9fe09c488e22f8761884ae3d2f3bdc71.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bb732541ca02e2f327e791449263c8a0',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/aae3e20ba4ee2b392400d74edb371414.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c4444777eca2a3bf4f40c8f9b1e76da7',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/99ccf5900b4997dbc8d125b5dbf36d5c.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e17a12f50c41ff0c38bb65ce82c16ed4',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/cf877a02c095056378d525c1db78f3d9.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);