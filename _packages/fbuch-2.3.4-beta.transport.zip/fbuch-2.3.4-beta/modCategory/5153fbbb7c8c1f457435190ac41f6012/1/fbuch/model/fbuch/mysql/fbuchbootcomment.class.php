<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchbootcomment.class.php');
class fbuchBootComment_mysql extends fbuchBootComment {}