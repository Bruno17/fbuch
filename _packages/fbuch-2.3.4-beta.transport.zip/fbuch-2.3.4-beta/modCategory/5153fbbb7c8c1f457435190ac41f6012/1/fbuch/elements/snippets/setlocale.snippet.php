<?php
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');