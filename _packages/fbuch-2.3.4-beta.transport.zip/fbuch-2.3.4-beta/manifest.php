<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5d12dcc84082833c46cd6733672c91bf',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/e746fa246514008834e662134d683c93.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '578d93902b8e53117c5878334958106c',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/daceb6ee53189ded1baddcedad126aed.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5caeec249d008b23f10638b5a37d442d',
      'native_key' => NULL,
      'filename' => 'modCategory/5153fbbb7c8c1f457435190ac41f6012.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7c501a4151432f9acd8231f97fba5505',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/bf1d0d253ea8a0ac81c6d91bfb1ab39d.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fff19dc1919f345c321501d570bba3d5',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/8d96e6b6297b12f35dc662695a0b7a50.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e30ec91ac58fcaff2c41e8a1a9bf2d4c',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/848fb79dd34bd8f32d9f2ce93723ac59.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ad91574b49426664f37e2c8fd6455521',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/292648b254cb09770f59e5fb4675062e.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6ca2d586cee46408fe111bf7aa150c50',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/fffc46e233d33f91891d18b6fc8c995e.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);