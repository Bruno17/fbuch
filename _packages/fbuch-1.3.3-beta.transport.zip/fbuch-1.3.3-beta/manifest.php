<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3a685802d3427a5ba1acaa7c82a45816',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/a1ca77ccf5e49a6bc2f9c06b7f6f76b0.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9f1e7ff42349e404f74d0d572feea635',
      'native_key' => NULL,
      'filename' => 'modCategory/35f1d9b1154e0629c05b23f9703a09fd.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);