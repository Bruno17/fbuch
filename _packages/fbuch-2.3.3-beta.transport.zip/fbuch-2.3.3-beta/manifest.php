<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '45a51c0bba2471d8dae40d474d8b4be4',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/ab92597c42edd5d43c9c68e482130c56.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '350f220890c5ea4f445a17df03156f74',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/52d47f4b9f020c9545e5a6e1e8f7bea0.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '092fdea79efaa993663d794ee9a9d777',
      'native_key' => NULL,
      'filename' => 'modCategory/42ee80eeec94114b7627dd791711f164.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2fad20650025aa9383356e14578384dc',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/de06cd8bfcd1824356894e3ec2e47d04.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '220b5cbfc6d4d5999228833a538fdfd3',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/55d9a0ec5a98200655a8feec4e9e1cef.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9155ae82dd33c03e29c3c2675f344697',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/fafbb8d6f99aabd72fba9c79c28b358c.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a317f8d0a624b7591b712f8691b48eb8',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/29ae465205220e0b7a375e0444e47b16.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2ed6af61a32ada2a570f9d407588c8c7',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/b67acd16b42e4acf65ad089b2cda10e6.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);