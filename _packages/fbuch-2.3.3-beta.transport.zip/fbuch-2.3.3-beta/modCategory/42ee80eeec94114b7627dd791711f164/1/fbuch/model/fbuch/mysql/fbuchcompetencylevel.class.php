<?php
require_once (dirname(__DIR__) . '/fbuchcompetencylevel.class.php');
class fbuchCompetencyLevel_mysql extends fbuchCompetencyLevel {}