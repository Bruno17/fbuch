<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5a6b50462cbf1bee35710d9d8f24f2f7',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/37a92383128ac14249c2e208a6015922.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '97be87b2d2a609cc06a9eccfacecc172',
      'native_key' => NULL,
      'filename' => 'modCategory/c7742b99dfb61e8833057feb8b9d48e0.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);