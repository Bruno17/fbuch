<?php
class fbuchBootComment extends xPDOSimpleObject {}