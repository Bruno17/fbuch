<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4704600011244a9239a61f1a4c4316ab',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/e70c8ca188b776b3d6f719bad1009632.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6579805609d5d3287c5383daee2ed3d',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/a3826c2b03755ba6bde4a61bc10ee4fe.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '53d9729920ad9bcec73fe981332ab72d',
      'native_key' => NULL,
      'filename' => 'modCategory/0c02a7bbd0a462da95b5ec5bf5574846.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '810ea77817e7486ea59df7ca08851ead',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/9ee08754ae21e2d6a057322f16a60159.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9a74d89ef9859495452c07ccc6060e72',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/103d36129af871c364cece16f3734858.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b13de8dbe5612209235f15401fb84db0',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/6c9ed0a467a78c526823509e3b1024a2.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e25f1dee58f6dd82f06cc7dd94760131',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/e60a7b4c75f92c912e0443817d33c32d.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd03e9aae0b5c70e54f281da8a4b85f34',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/ddb3c282cc467503a0b8d2bff7a7c52c.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);