<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f3f6d02d03fac2537d331c986ad03476',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/259448eb52e41c78ef6849f20aeb4c9a.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54a4faf3cc8f884d1c70e370660c20ee',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/93511119d049959d92f65c2a3af5275c.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '98aa2fcd3e770943ec490872b77e1dc6',
      'native_key' => NULL,
      'filename' => 'modCategory/dbfebbc473d90bb409b80e987c373cf3.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f517de7a14b773f237638fc199570105',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/6a4bec4e1023277998e8438edbc66382.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '426a28c225bdcd4a965d229ab6546e76',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/ccf501b9bef1983a601f301090f90aad.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd40ec637cdfc2ab0f2ce60deb432b9c1',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/0efce111c1c46a38d90eb33d129c3209.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '782d57a342fe94380d5ba34657e7f9d7',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/f4c55e9bcdbd1b80fc5ffc8b7c410976.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4b88480df07fd177d14c67dcbbeacf17',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/4e31d64d36bedc1b45d6165a8cb75ac4.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);