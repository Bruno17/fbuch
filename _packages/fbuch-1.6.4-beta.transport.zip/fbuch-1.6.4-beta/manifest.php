<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '188ae56dc0b8f9ac514397cb19156cde',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/11a3bd272c87b8e58cea9b2201510ace.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c7e86d384bab81baedd92d17e1cf4ca',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/bc206d07bc9def3667b0c6243b6e7610.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '496f0c2e067a0454a7e916c0dc76fc74',
      'native_key' => NULL,
      'filename' => 'modCategory/f875e05a7fd352f1ec3f92d9b0d15d59.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c8d472ee048420242b69fdb10015021f',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/47aad28116c80f55a7db30d1be003edf.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f4779af152c8eee682c89cd6927528d5',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/90e3b210ab5906c52b4e713a59ae9640.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd41a47b6c89e20461bc6753d6b2aec16',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/5effe0001645e07efd8ce87d8566c3ed.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ea6b7c3e8fb06e76e45453e9480b844a',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/4ac8e1af12b21971d4d72b1fdb1ddccb.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e710cce8ebc1207a53e2249dbfd33c86',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/79d20c991226a4a6715bdb72b9a9ac59.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);