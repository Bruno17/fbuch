<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ea4dbe6716c89cf23d95e8fe89cca1c4',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/41ae6376483972c1dca80d6f07a8a51c.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8939f52a66f533e255373b803e06d66',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/42ab0a8f82a1ea5fefa291b5e190e18f.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '17da291e52cdf0285eed32d360ceb3c3',
      'native_key' => NULL,
      'filename' => 'modCategory/4461a7c2a6d85473215c65ac23b7ea2e.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9e928424ce43c6a5ae5028f19858bb59',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/3d2dea1f80d92ccfdafa2ff18404d232.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0aef9c7b6b5c69ecf99649f990031bbc',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/e138298270eaea420b7b52995ca6515c.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '11dc959e0572099e1704a6d35e5adb31',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/ede778611e6b60b1d806159fe50bc75d.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '267cf32f7d855291ccc32ace95d1712d',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/5b159a0c13b1f0571710cfb34ce62b87.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8413b1a1f630d719cf9eeba29625e0ee',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/bf4726181dd19b9f2127c07066c58d3b.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);