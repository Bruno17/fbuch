<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b0d7c419800bd40af964057e5bb52732',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/47a8fd73d3b5d1fe86b5d7d7dcb5f580.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8ec45e27cfa30748e15c1cc30ef3c09e',
      'native_key' => NULL,
      'filename' => 'modCategory/e9b891a5fab0336ad9fbd09eb2b81e30.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd0a612a0b5fea2ffc664ca9ba3cf575f',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/1b282e405cbf4113e398e45f591b50c7.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a4d42dcd3b45eedb663af412c2b3e915',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/d5de37a4c8a9c420ff433b168cf8580c.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '63640d25e9cf42f6b5162e06c8f5694e',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/29ffe4a5636eff5aab507081a715eb37.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cd1ddb6cba5c2582b4195baaea9ae8bd',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/91cfb1e2033d43b86e2bd335bab53e79.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0664679b3c3fc5f8642b1d80b1aca80e',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/91acab1bf1b25c36aa97d763994bcff5.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);