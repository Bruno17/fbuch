<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '055b2072c52efa63fb7a31bb77379b60',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/017fe343e5742b6c4aaf576061cf9132.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84cc00be19d89139710f5f1c36b908d6',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/5fcb9be28f56ee56dc2408fd9c7a26a2.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '83bcb15c32135374b1e100a0acc1c22b',
      'native_key' => NULL,
      'filename' => 'modCategory/23f613cb1d8e8d30b7c0366e1d2e2313.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1b3d61ee99f6231eeed9bff41eb06ad1',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/c3563c9e66f7c86537b67408fc176baa.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd3efdd120ba4d0b7be8735b3a5317900',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/52c6b6a1701d06c03794a520c51cb93a.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd7fa600eaf3f439be7483150b942f56e',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/1db6e2d83546208837c8b9ed8c339260.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8c5b3794b3a6e2401afe0e68bc62a2ae',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/124bc67d47cbb4f887002f070c281d64.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '10282a94db5a5bcdf9a447e3d73a58d3',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/0d0269df6ccef47d5363aeb9d12b20df.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);