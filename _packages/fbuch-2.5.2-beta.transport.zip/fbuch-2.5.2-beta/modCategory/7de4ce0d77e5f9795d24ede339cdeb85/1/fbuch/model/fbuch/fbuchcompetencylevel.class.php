<?php
class fbuchCompetencyLevel extends xPDOSimpleObject {}