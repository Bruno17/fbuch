<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ecf43609f5358ff8bb69a055269710f3',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/b220bfd4733df476880f82fac49d67ee.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0214f1bb7b7791c1221b6e5f9424515',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/c130f659bb0ce6f30e5f37716274137c.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0c30a1043b57808f083a68145c675cb9',
      'native_key' => NULL,
      'filename' => 'modCategory/7de4ce0d77e5f9795d24ede339cdeb85.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ba30ced713ae5b1dadc666d0618e510e',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/da8ca13e4cca884306215d625a33da8d.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a5bbd5d59a048678627ffbb3869601fd',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/f3fbcb462d8a2b14c71beeb6990da969.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '302486b9d8ccfefd28818c958f661320',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/1a08e45f1fc5ba3323b29b975b5f0ba6.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e0efd7318b9bca8cfc255608a8585035',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/717ba290d862c7b19cfe3c05784dab34.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ad26917acaec97abfcd0b9ef4d70ff0d',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/164da4c1a22f60bd61b729a77676b426.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);