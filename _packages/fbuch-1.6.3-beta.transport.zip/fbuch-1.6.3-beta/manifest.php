<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5f00ce7dfcab2cc755c77062bc2d61ac',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/b502e8a77d0e2a15dddd6bc5f1c29e65.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '27c002726caff717fbc72a321caca8ca',
      'native_key' => NULL,
      'filename' => 'modCategory/cca9f56371c76b538efcf19c43dfc3b7.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6e9b5add4cacdec96bb2b7fcdf90ae3f',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/e5b147ace87b9ce9b88ec3b4396b1825.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c8719e9047232dedc27d84749eed4336',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/bc73a482f7055b95f120d0a5336d1f8d.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '02e85edd1e5db2dfef6a85111b8cb74d',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/323bf367a6f1218de77c67ae7a8ab0a0.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b603054c1b094cf9579df7d9a4ca0435',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/beb3ed45dc945634371b039180ff8e59.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0d7529cb3d240a47a447f8484984aa23',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/7c3e1babf82e3f234f8e6e39f22b01b5.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);