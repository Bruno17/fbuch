<?php
class fbuchDateInvited extends xPDOSimpleObject {}