<?php
require_once (dirname(__DIR__) . '/mvdooraccesscode.class.php');
class mvDoorAccesscode_mysql extends mvDoorAccesscode {}