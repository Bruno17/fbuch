<?php
class mvMember extends xPDOSimpleObject {}