<?php
require_once (dirname(__DIR__) . '/fbuchdatemailinglists.class.php');
class fbuchDateMailinglists_mysql extends fbuchDateMailinglists {}