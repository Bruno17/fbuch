<?php
require_once (dirname(__DIR__) . '/mvmembergroup.class.php');
class mvMemberGroup_mysql extends mvMemberGroup {}