<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a6511e68f874460efe445fc43da707e1',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/2e74080fc8dfeebd75c78fc5db58ed81.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7da8998624ca35a9ad11e43393a4a80',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/c8d3db379244185dea1950632ab75391.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '096e2798c695f6cb7d3ee36c705bde2e',
      'native_key' => NULL,
      'filename' => 'modCategory/156e56d09e7e6f392de14e2c7a14380e.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1735fc4ddb7d4825b8e212c67abbd166',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/61f51f2a622cccb9d72042cf15b2ff54.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4d28bb6e081e5ce3e116a1106335a876',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/60c03285e32041ee43dca7114c916346.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd529fed987e36bb9e86d227e099c3851',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/c39ad5a412e8bedead6ff2b7f8772c9e.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '766348a0a839a3d79b17ff82ea6fdb63',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/fe8a4ca4d8850d298612d5463b47d39d.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd53b4700c4c3e2f7619d7a37d2fed9a1',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/67f360f263e5e163ec1fe58b1744df51.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);