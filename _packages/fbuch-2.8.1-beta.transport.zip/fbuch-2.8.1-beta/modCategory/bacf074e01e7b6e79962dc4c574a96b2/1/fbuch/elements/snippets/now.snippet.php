<?php 
return time();