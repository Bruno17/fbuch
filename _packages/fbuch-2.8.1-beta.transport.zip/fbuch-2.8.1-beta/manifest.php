<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4f4d1c90c6d590067826cddebc42db1d',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/a5fbc5e41c08c6b991d84587a4e45a32.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8345443b9aa96408b9169e8ea866399f',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/dfe7603b04715042b1e1f9413c8eaffa.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a0d266acdfbcd52fc75d24630f0c6400',
      'native_key' => NULL,
      'filename' => 'modCategory/bacf074e01e7b6e79962dc4c574a96b2.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3f0475dd5d777c6e3afc9215d8a08fe7',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/e7bd093dcf10568e952b34939b777586.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2049412993212f864584660b8971ce4d',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/a8f44eadea21bc83b69929f2d8fef64a.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1f3d5d7dec8e26ac205635753cd83cc8',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/d625f73753c8bebe5af52b8cd01487d4.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b4f70b9af043589b253e0b19bc2baf36',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/1d12408f01b7aefd5325f1185ed7dd3b.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '13564226315a9258ba8dfda87ad03007',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/03aa7df131fbd8f42ba8488620ea902e.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);