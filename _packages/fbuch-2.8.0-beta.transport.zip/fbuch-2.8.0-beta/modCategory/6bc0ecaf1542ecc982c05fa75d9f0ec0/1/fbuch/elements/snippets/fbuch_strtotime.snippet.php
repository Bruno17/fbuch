<?php 
return strtotime($input);