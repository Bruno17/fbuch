<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6e3dd62ce3925ca986b68e43adb303ce',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/d33a3b11a90f85b0cc37899e4a49a04d.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c66f94d1c8a871049ebf7d81c75340b',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/37b6f83bf87ad580478cc8d69f6180f2.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'de3b5e53ac8d16b1a7ab3193a55c8ccc',
      'native_key' => NULL,
      'filename' => 'modCategory/6bc0ecaf1542ecc982c05fa75d9f0ec0.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '917e2617c463e1e528a835e089539400',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/41080fb86e677d8b496714afd943b363.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '13e5ea97656af5d562ff69463dfbeed2',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/e86df5d54a426fb970491680e7f33a64.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '57e36580b93a21315d8cd1a44c1b114e',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/30e98d9ad01dfd664274ad3b4c1f18c1.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e335bbcb06a771ce916849f70c0edbf1',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/049389b835cf9851d1ec1a24ed69c846.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '20390e9c2a6d84e65b78db96ea2cf5a9',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/c3968d37fa094d9c56dd55604383587d.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);