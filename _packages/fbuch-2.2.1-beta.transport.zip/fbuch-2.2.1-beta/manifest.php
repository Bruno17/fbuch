<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '451ab7c60f61e5b0751522a576c729e9',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/82c132dd38c5c234abff427782e6feb3.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a941274f4e2d745b87a0e858a658afb8',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/d12a700c7bd19eb2844d97deba083c8d.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '52e10e5e24d4b6c1380946d79d0109d0',
      'native_key' => NULL,
      'filename' => 'modCategory/f210a8bba7220d07f7c9a5212464e415.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2141f37afbbb8f0915a7e49965724e5d',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/e97171c67feff98642bb93121069b9f4.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9f22e14ec04272d0ef9b0ad386f1720b',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/c21e3eb7ca942c9bb0b2a57e27821287.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '51628539d6d08ea9cb28b5357f78c6b6',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/5b661854178617d0d10fba7637a729ac.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ebf91916825cce4f4fec7b6f9106aa6f',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/209441e58ca3ef25123cb0d278ff04d8.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b294518b6bdd4a775c9895e92715b58d',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/0c68d217adc373d6ea724d644d2e87de.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);