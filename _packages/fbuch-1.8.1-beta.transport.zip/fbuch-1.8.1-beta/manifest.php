<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8f8eda7bb9f9f484bc118ed8eaa6ba06',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/82fa08f5331f2f47a96a75088710d816.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47f8f3abeb6fd2e8c3adeeb37cdd7873',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/8680b25c15f86b2c289cd5da04693d12.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ccb488eb065b702709e0f3060de97740',
      'native_key' => NULL,
      'filename' => 'modCategory/fad3a4d51d754365cd095362257599dc.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1bec7775f7887de29fa2d2e8617402db',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/ade7fa40e6f062062944921edc4a3600.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ed3d40e7e02f0deb2f549dd2b85ec500',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/c9893c3e9e14a8a41e9a48ed53ba2d46.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f52f5b6b7ff51c31bf07bc16454259fc',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/12041e9ca7155d8809767a49efc58628.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e5168677815228024a0f974bfd162132',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/b51974b971586f3b8a2828988b944307.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4acd94e548a8ffe298e1c88738c875ad',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/19d0288204b9478411fc7c1d3df385d4.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);