<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '91d30e7f7ec02ab5afd33ec035fe40d1',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/cc802e8c17fb179774c3b075e0333276.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5cf13c108584184484e1184c99ad15db',
      'native_key' => NULL,
      'filename' => 'modCategory/444e4d0922103bfc1a0145b882c20a14.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);