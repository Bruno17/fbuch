<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bd02c234808cb32adb30ed9649e949a4',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/419220871e6c1f52f4cc4ad0184ca162.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fcfe5fcb812b1246f5e6dc24d703b6d',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/eb5167edaaa4046788ff577a6d4456fb.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '30f82a50b7148e907627e50dab81f40c',
      'native_key' => NULL,
      'filename' => 'modCategory/4e40ba7b7a50b82ae24d581f12f60a12.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c54b702ab9cdd808edc8b89c2051aa57',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/3a96c773318451d4a97e6a51cd74eca0.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8ff446e2b1b9a423bb62775d1600f429',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/043f5895655e00a573d6a0b7b15206fb.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f567412adc9fc1af1e1c28917a293b49',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/2c2a7f3272f0d812a230b9977dc9de01.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd8eb0674d32b84da060fb85a0c9fa0e5',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/60c5ff76af4a67658c43bac74229ad06.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '364775626f9cbd1aa999764812ac6042',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/0a5240f9699366739068988f78438e24.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);