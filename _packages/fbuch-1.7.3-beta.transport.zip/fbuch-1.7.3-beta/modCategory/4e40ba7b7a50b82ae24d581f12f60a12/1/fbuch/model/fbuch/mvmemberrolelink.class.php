<?php
class mvMemberRoleLink extends xPDOSimpleObject {}