<?php
class mvMemberGroup extends xPDOSimpleObject {}