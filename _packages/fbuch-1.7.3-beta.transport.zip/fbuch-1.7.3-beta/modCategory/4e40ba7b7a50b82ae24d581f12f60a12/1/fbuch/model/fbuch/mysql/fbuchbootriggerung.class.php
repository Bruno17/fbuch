<?php
require_once (dirname(__DIR__) . '/fbuchbootriggerung.class.php');
class fbuchBootRiggerung_mysql extends fbuchBootRiggerung {}