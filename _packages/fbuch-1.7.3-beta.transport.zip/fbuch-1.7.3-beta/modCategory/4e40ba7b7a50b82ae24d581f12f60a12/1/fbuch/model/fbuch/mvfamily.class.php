<?php
class mvFamily extends xPDOSimpleObject {}