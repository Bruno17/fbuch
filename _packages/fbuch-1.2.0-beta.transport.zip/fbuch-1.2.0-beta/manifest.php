<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '89b1917a7696e473eeaeebaceb752226',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/6d51bcbc5a65d717a4cade7044c3061a.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cf848b393da610b123b48ae14036234b',
      'native_key' => NULL,
      'filename' => 'modCategory/aa028ad8f54c5553bc7f0c6956ab63de.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);