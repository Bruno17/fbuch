<?php


return strtotime($input);