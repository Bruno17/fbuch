<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'eb2523a5fece471afd0ba63678f82193',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/3695d400e67fde364fdc09249cd153c2.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c92433b5884bc58fc913da56a8f461eb',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/fbd2ba8f26028ef4082bf73b95019d70.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2712cbc74b7e9dbaa953b88359d87a3a',
      'native_key' => NULL,
      'filename' => 'modCategory/cd891094841ce09bb9a14b86cbfb8b0e.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2d34c4f524c90f834bc0083c6e10b9be',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/65cc87f4c7445edc3f0498c4cb5372fd.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd1102076ba72e7453cd91943a19b1c40',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/930a050d9c3e87f021ce2503e94589fe.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f66dfa4858edcd4453996e6a42814584',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/0ad5c0d0d95fae810367644348bf927e.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fb38139915964e629c51ccf0eeab3698',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/ee33f34ad089b0dcafcebb0d61ec59f3.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7e29761cb91ba922416286f29680ef95',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/0ae712c94528be347c466f89814e10b2.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);