<?php
class fbuchBootsNutzergruppe extends xPDOSimpleObject {}