<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3a7a5031a7db3fac7745656c4ff17b5a',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/b0b8aadd5465a489701b1370a5da1538.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '247793cd3be3b2a5f3fd4c308686325e',
      'native_key' => NULL,
      'filename' => 'modCategory/1bd7a0b2223b66a20173df7663e2927d.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9f51223d94a2c57ab993b6436b0f4ec7',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/965aad9e4795867eea442e85290a3cad.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a49e2dffff4900084917b874bc657086',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/7746cecd245beec4594f2648507aebfc.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd8496b8b38f2e98b3399b3b11d1ae576',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/86273421149fd883ea46dab48e9ed2b5.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '88808bcc142267203c3815a03f1df157',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/20b7a7ab76abb29517b10a2fd336e4b4.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fc17344e514bf0db473ae6f01e3e47cb',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/0a0217cba1eef28c56ac7f574a77d02d.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);