<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a16a807843a3232b911ad93df5bfe12f',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/faa964da6674446ff872ad3cd4a5035f.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fc168680d04a334bb2f6f7479dc9f96',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/eb198218066cc52d7e1a7ba9fd2e2c5c.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b78e944b0f8340ce92eafcd4d489d68d',
      'native_key' => NULL,
      'filename' => 'modCategory/398f9c510eacbf9e75d0cc061238fbb8.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3c1a8dc9d15f2c0abd33449156712eac',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/1cb72ee6f92b4629124c4221a8a66878.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '556f223b2c78f01c69e6cc92175bcd11',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/cb503787a52a5165ff154f2458d7b30e.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '21bfef135f66e9b645cf5fd40c1a5ff8',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/07a5a84de5826f36dfc065997f107fea.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7a32873c3a0d62d87aa27d1638bac599',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/5626af14cc46db544eecc85a21c224a5.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '778a6a8a154a1e1f22a16e8e43d254a5',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/37d424aef4a9400fc80cbfb8c2c38b39.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);