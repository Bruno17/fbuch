<?php $modx->runSnippet('fbuch_is_element_used' , ['type' => 'snippets','name' => 'setlocale']);
setlocale (LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');