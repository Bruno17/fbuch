<?php $modx->runSnippet('fbuch_is_element_used' , ['type' => 'snippets','name' => 'today']);
return strtotime(strftime('%Y-%m-%d 00:00:00'));