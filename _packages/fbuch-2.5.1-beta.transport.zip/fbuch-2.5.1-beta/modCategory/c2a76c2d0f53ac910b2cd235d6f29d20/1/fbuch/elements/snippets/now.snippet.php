<?php $modx->runSnippet('fbuch_is_element_used' , ['type' => 'snippets','name' => 'now']);
return time();