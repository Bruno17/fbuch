<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ed631c94e3809d9c6e0e95d32e251a63',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/f0d068666ff80277fbdc17b70d35d772.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bf4e561d19379a03b65b5a24ba6c6a3',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/3da10904c04d0ec7cf3b10938db548d9.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6714163d83e3d3f766bd24ade3987f79',
      'native_key' => NULL,
      'filename' => 'modCategory/c2a76c2d0f53ac910b2cd235d6f29d20.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f57bae5d519fa4cb879f86c029bc0ebe',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/9def190d24bd07dd0495e6a70de83d9d.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cbd85a802149a856969d694f65e6c408',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/3343707904d7410bf01dd4d661084683.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '877bec33b8737f1ceb8691bc83d18566',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/a05de05ee265f9145236175a8e4bd08b.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0a3e2bfcc7c012b86c2f4dd2eb3092a9',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/570be4fe11977c89b5983cce60ef7695.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2adf17c1939636da8ec95005cf7645b4',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/696db38558b070bd41f0d310362ceefa.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);