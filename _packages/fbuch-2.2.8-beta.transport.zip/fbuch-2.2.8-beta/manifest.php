<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7d8a4fde38ea364f5df7f1434bd51df8',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/81b3d73ee4aa72270ae34050231b35eb.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5843df81c440b74bd2f062a174bb5bee',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/ef3ab0f68c090631475dac03b36fa592.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '07219f154b2ea06817da64461fca80da',
      'native_key' => NULL,
      'filename' => 'modCategory/79016a95de469e3ee7932e09a4204f76.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7dc4c6f4eb9e57bab475de93beec73c1',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/823525b474e0c7f949ec9f4d55daec67.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '026b128de4fab2dbb005acfd969d11cc',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/749e1ecbe4f40e904757b5cc280bcc97.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bbdd9ce6697b843632bde3a85c2e096f',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/a87aaf1372ca4a7b606b7cb96529a9a2.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '018478b68fe77fc7492ba27bc20addfa',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/4fed6f4cf46117b91c061ace83b35a0e.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cd1ab3149e5c8fe66c9d6deb86bf688a',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/6afdb3d577f5c716fdde3b2d332e56ca.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);