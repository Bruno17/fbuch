<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchdatenames.class.php');
class fbuchDateNames_mysql extends fbuchDateNames {}