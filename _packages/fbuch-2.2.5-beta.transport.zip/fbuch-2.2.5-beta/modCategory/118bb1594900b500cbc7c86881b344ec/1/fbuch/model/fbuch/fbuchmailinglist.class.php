<?php
class fbuchMailinglist extends xPDOSimpleObject {}