<?php
return time();