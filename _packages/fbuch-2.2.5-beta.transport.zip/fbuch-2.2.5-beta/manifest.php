<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '04dcfae309d7c8e5dc572a918b175fe9',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/aaa4c76e7c8197d61d36fe0d97b86995.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f840ac6d296fcec453a23243e27e1f1f',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/eb02a06dde1a645daab29a12c18de62c.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6e3ace318195cf5af711338f18a98891',
      'native_key' => NULL,
      'filename' => 'modCategory/118bb1594900b500cbc7c86881b344ec.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '25dc2bd758f4190fbfc492d28706a733',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/e168c48bc74eb82f5cf9bbe97c60ea46.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '65528a6b2f0c994cbae81321e784722f',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/88a0d834da60c03f663d398428c8cb9f.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cbb9ec73e9c28a85458b287852d9ae7d',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/033264816e4effa6ec8bb5b71d3cc995.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd5e0825ca9a398435cdb9120564ec414',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/ac346012770dc4be86bcb68f828ddf2d.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '56d32c9f826c2a87d2e1c5044881a0b4',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/874dca4f4328299cfff083f782ddae8f.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);