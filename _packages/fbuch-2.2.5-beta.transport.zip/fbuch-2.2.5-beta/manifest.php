<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e67e8eb92a3d5cf315cf806895f8580f',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/8d8330c6c3a80f5b77091a2b49711026.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a613beb0e8422b739cf9c33ca5120e9',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/43fb6c7ca71d098817a94e59edfe6f59.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ae36ad7b4328c2ff2bfcaf9ad7c6b253',
      'native_key' => NULL,
      'filename' => 'modCategory/ff6c4ab4ea97985fb7926e54f19f6ede.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0c4d744b9f745a165a88869794aa7a86',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/9ab40ffbb4d92c7c873f80a09e517250.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c4bfc5e5b040ef4ebcf22d5d84ed9f55',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/b9b1f94d8d63466d9bde6d0e2dffd058.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cafbed8f9983e890c54994617d0e9ae9',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/2b5d970874a3c6551aa6da67a9f9f00f.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'af39413a081ea254ce7f1ee9ea38f7c4',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/ecbce90f33ab5d700c1f5309b68760aa.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '784b29c1b9faa9411d44a35244e6a4f7',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/61b401a8a3ac8af53ddcc422254a6ca1.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);