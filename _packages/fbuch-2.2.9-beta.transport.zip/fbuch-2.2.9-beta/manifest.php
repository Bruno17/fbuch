<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c68cc3e5c26912e6bf14a32f67af900b',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/53ded66d94c0db62afb8fa0f4130a83c.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18b7ca08d99b0df007154691bb529c25',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/f999e956c57e2c1de45e7d5556b5f812.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bf1318b5f2be1dae2a1f1b70a488e3f3',
      'native_key' => NULL,
      'filename' => 'modCategory/300f6853a022d80019b7a6536f32e963.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6d4a9df57c76e3574651edf4292dfeaa',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/5389e9f5fc04ec783d02e4af63fb9a1d.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7997658336283fbf951b5cc0a6c85dc9',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/dfe7f3d430dca9d678bde2cbf5c6f671.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b040088632534a46d1f17ae8409d8155',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/bd4c8226b5469b73c722a670597252d0.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3fa051b7ce37d87c9eecfdecb9962b53',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/5b5888da5a6d8d089f86c4a3d75fec7d.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e8b6e9f57d681bd15e5c5cdc0c202733',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/0cd2d89b34ed6a9e36aaf68faf355318.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);