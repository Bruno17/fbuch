<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '62224a9681fb689979156b8aa6b0c2e5',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/137c8fad5b50682d6c46b1252f78ed4d.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fb3a13621fabfd3cc9805bead0f964e',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/7c905f253c7b51cdc851fbef417d29e4.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '633d0138fedf6f82c92a0a54876a82f8',
      'native_key' => NULL,
      'filename' => 'modCategory/e44d39026193a60d52cd891c8ede3cb8.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0f354a645168b54d33304b807bf0caf4',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/421bb0384c4ead1acd721cb02d0964b4.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '084ac54e8770abdaf4e94527296301f7',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/b85cbaaa7d15d96335670f496a9ea39b.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b4d9f58851abdd431f5caddf1f3d9ad4',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/586eebab73804d765f81903b506be574.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7bf6f1cce897beb9a56165faa85daecb',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/a05b4fe0025809a3f8d04f18b9118a24.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '94bfa829f8731ce580398412c26a65df',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/2e051b221cdd3df41bcfceadb70cd03f.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);