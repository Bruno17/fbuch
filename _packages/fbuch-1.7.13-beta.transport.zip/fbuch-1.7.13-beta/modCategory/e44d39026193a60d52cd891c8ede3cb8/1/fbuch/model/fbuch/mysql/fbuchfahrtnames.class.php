<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchfahrtnames.class.php');
class fbuchFahrtNames_mysql extends fbuchFahrtNames {}