{
    "custom_fbuchButtonBeiElementRegistrieren_show": {
        "deleted": "0",
        "group": "Site",
        "tab": "",
        "caption": "",
        "inputTVtype": "checkbox"
    },
    "custom_fbuchEmailTplKontakt": {
        "deleted": "0",
        "group": "Kontaktformular",
        "tab": "",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuchMitgliederMessage_0_show": {
        "deleted": "0",
        "group": "Mitglieder Message",
        "tab": "",
        "caption": "",
        "inputTVtype": "checkbox"
    },
    "custom_fbuchMitgliederMessage_1_heading": {
        "deleted": "0",
        "group": "Mitglieder Message",
        "tab": "",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_fbuchMitgliederMessage_2_einleitung": {
        "deleted": "0",
        "group": "Mitglieder Message",
        "tab": "",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuchMitgliederMessage_3_body": {
        "deleted": "0",
        "group": "Mitglieder Message",
        "tab": "",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuchMitgliederMessage_4_schluss": {
        "deleted": "0",
        "group": "Mitglieder Message",
        "tab": "",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuchPegelWrapper": {
        "deleted": "0",
        "group": "",
        "tab": "",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuch_benutzerpasswort_mail": {
        "deleted": "0",
        "group": "Benutzer",
        "tab": "",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuch_contact_email": {
        "deleted": "0",
        "group": "Kontaktformular",
        "tab": "",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_fbuch_contact_subject_options": {
        "deleted": "0",
        "group": "Kontaktformular",
        "tab": "",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuch_invite_mail_tpl": {
        "deleted": "0",
        "group": "Mails",
        "tab": "invite",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuch_invite_subject_prefix": {
        "deleted": "0",
        "group": "Mails",
        "tab": "invite",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_fbuch_lgnForgotPassEmail": {
        "deleted": "0",
        "group": "Benutzer",
        "tab": "",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_fbuch_login_pagetitle": {
        "deleted": "0",
        "group": "Site",
        "tab": "",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_fbuch_site_logo": {
        "deleted": "0",
        "group": "Site",
        "tab": "",
        "caption": "",
        "inputTVtype": "image"
    },
    "custom_mv_datenerfassung_email": {
        "deleted": "0",
        "group": "Mitglieder Datenerfassung",
        "tab": "Mail",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_mail_tpl": {
        "deleted": "0",
        "group": "Mails",
        "tab": "Serienmails",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_mv_mitgliederDatenFormular": {
        "deleted": "0",
        "group": "Mitglieder Datenerfassung",
        "tab": "Formular",
        "caption": "",
        "inputTVtype": "textarea"
    },
    "custom_mv_sepa_ creditor_id": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Vereinsdaten",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_sepa_beitrags_teilung": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Einzugsspezifische Daten",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_sepa_belegtext": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Einzugsspezifische Daten",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_sepa_bic": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Vereinsdaten",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_sepa_collect_date": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Einzugsspezifische Daten",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_sepa_iban": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Vereinsdaten",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_sepa_last_collect_date": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Einzugsspezifische Daten",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_sepa_msgid": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Vereinsdaten",
        "caption": "",
        "inputTVtype": ""
    },
    "custom_mv_sepa_nm": {
        "deleted": "0",
        "group": "Sepa",
        "tab": "Vereinsdaten",
        "caption": "",
        "inputTVtype": ""
    }
}