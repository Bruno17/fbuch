<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ced5bbd8bc67f183341f81ef851f1127',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/1a36e895a5b19e0723bc78bde8cb435b.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6a030dec31b8cf3c2f5f3a2568efebf8',
      'native_key' => NULL,
      'filename' => 'modCategory/e659afa87782ae42b8935758a72bc907.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ca48b1daaa215e6987c01e2f20a3d231',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/3183527c7443a44ccaa413396273f7c0.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4f3d9cffbd99d42050f240f7a425ff92',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/10efb8cf4fb7b46e282779be60f46d5a.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a63040e27c99ef1b0e8152d9b7c97e34',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/721df7c22092085270deea76153d5073.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a12473bdd5e14f37818143d737067333',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/52d173e729c417164c86dbc23f068c12.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6fbc7662c4e0286649c5129c28ee7001',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/54ddf3319ecc495d1a442e763c43e185.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);