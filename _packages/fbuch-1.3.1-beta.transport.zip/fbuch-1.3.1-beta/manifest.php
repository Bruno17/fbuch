<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '650ca97dbaefa1b15a764761a4d44a5f',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/4dc2193dc3c17dac6e8aa6e2699b855c.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3bdc533c4806609dba30a8b7dc824480',
      'native_key' => NULL,
      'filename' => 'modCategory/ec9e12654a5e6ae65be4a1f77ac4e5ae.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);