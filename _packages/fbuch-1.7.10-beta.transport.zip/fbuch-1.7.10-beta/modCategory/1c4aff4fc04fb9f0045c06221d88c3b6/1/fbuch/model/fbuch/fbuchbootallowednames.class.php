<?php
class fbuchBootAllowedNames extends xPDOSimpleObject {}