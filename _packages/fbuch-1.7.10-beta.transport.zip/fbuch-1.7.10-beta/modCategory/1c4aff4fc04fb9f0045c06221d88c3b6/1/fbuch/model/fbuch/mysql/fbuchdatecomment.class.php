<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchdatecomment.class.php');
class fbuchDateComment_mysql extends fbuchDateComment {}