<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8c50982390509319b213ffb8c5df464c',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/1f6d9e8cb94721e495ef8e65e118478c.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c1e7766c1dc84394213fce76d0b2b20',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/b252893ffeac109e4d3cf1f1e4870005.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3b56439b33130a963cd2d0d258723ac0',
      'native_key' => NULL,
      'filename' => 'modCategory/1c4aff4fc04fb9f0045c06221d88c3b6.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '05fe608ce1a81b404d1ec694fa98aed6',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/d65295d8d0bfd443890514ebb34190e5.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'dd75f4a14dfe3b455abd1bedbae90077',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/36f46cf35a13b4018a5aed1393497735.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '73d9e7ce2e5d7331061ce2eb1d1e6080',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/9957c554e26b91f52c89bef4ad4eb5e0.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '171b811d0be6f55b711254abbf06994b',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/1c4179cf65e17ab81f4284659aa97cb3.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b380087034fa6a3a7e28d0579394cbe1',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/9d65a7d0730e90ed1b27f56893300df1.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);