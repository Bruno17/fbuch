<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5091c4357a2940daae4880278b17a503',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/d45d1f09b67127e7965b340d7b24716e.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '05e024b521c6be453309b55e84c91aa3',
      'native_key' => NULL,
      'filename' => 'modCategory/81059371514237f80aad4f5c7bb79236.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);