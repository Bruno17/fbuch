<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '82c4d82de358d9bb3a0c3e938cd78f61',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/8bbc4ed27c8e67f09f05cb137abf8130.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3850dcb5e9b6e4b5c0426d88079c1385',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/c906146f201744f4c58451e325de9a85.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b4846dd976a47b090f64a0eb07b6ec35',
      'native_key' => NULL,
      'filename' => 'modCategory/3639d7483375b118780493f4b5111338.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd74c04ffc6cd5f02ccd7a67c943270c1',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/c2632e16b75d03906753697b43d05066.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7ad2e5a3b15f9f18b29c2d7f7d1c8718',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/4fcf088d4f79e868de09dbca061412bf.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '97edd986945274142c90372ada345dd8',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/0360341728c9f7503e2e72f6c08290ac.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bccd20425c14f0aef39be7cd7f1cdf42',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/3add56af3ee40a4cfbf72e5beb1cd378.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '261316a99453eb2f3ac1353f637a1b9d',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/e736ff3b1f393dedfa05908a2cdb2f40.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);