<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ace7336db021cbe90f2432236856ca63',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/f435e4dd318b7ddbf58bf27622977f07.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '174bcb48af2d71741e55712f26fbf6ba',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/9518aa065c460465f73768fc2f9c2850.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '76cc542af6e51125246bbb6f8f9392bc',
      'native_key' => NULL,
      'filename' => 'modCategory/9b65f5abd080b02a9ecd11d5d371132f.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0e9fb13004abb34bbad5c7294b8bec57',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/8aedd09c668ec2f765a8b1c84df02cff.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '18a780a45da85cccd2e9f7d59d5ccfaf',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/49ade3fe145ddf6f123adbfd293e92ab.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fcfc8675fbfc40cb0db17540759067a7',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/e55e35a39517ebe5de774862bfa4ff06.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b2dfcc64909a872f3e3f0a5eb947758a',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/12285f758ffcfb7d5430024097a3b94f.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3daa52f6da3dbfa937d067a2ef540d5d',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/bc0ddae465a78801ceafc253901067eb.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);