<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9a3243ba343e7c5e9756868442296d6c',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/6dda846e622ab085f77e48a071319b05.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a08201bdb3247d8bbaba198d32c60384',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/808d728e53d7f5ffb178956d1796ab6a.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '25a56e79e85a21f396732c9e7631b018',
      'native_key' => NULL,
      'filename' => 'modCategory/63977fdea4adbf1ab9a5b10b4e64f0bf.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '463acc77da39a045e7bb005367142c0a',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/5345d670a3faa0defe75f4218757ab6e.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c457378ed335c75ea77c2db9de1424f1',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/217c11c175ff79e7b01325aceed785ac.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6efc1f775d81f356a5e3557751641958',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/76d9bb628262b537c789ec61369c71b1.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6627542a5661d8ffad839e42c023663a',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/8effe88ced1710e964cdd5950b2853da.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1b42de5645f1c558c70f2435c5b4c0a0',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/216aaebe8747a9f67d6a199495c095bc.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);