<?php
class mvMemberState extends xPDOSimpleObject {}