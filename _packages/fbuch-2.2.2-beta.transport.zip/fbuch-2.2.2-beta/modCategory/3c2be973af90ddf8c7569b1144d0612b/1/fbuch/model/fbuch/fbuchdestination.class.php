<?php
class fbuchDestination extends xPDOSimpleObject {}