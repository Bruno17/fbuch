<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchfahrt.class.php');
class fbuchFahrt_mysql extends fbuchFahrt {}