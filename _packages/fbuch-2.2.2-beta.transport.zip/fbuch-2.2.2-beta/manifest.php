<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8a5fefd3dc02c62a86033b7965b54022',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/9ed1bc5d4d06e1c963036b26dedae2a6.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '056b7fc2f248afb87e7d98fb38318664',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/d5514e433f72c271127c5c5290ab10ab.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1b597763ac4ba03c093d26e393f94141',
      'native_key' => NULL,
      'filename' => 'modCategory/3c2be973af90ddf8c7569b1144d0612b.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '57cf89d271646e7041d622a5932ea04b',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/07aaaae75134909b8a131e8f84487c8b.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '688dbc9e073c5fa96484eacb1d16765d',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/b5b2237cb681a70b498f78bcbb367af3.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b5386e74b4cf4f477f5f9bc2466422b5',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/bcdac3b923d1fac5c66810a5ffa7e9c2.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c24705033ddf1327e8618775ac6802fb',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/e6a5a9a42ee400b6f3af65b0cebc4535.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '520fd26203f57acd381f9834738eb9c0',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/a4cbae4dbf0e288a312d34585df8223c.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);