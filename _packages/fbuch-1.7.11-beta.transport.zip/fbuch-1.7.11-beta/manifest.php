<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6661abe6baa5dc3c4565d8bc55ddfef9',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/a78fb4e478d1d7dc7c617b450baf7f4b.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d47aeea088806a49a21882eb3811764',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/1b2cc32424fdc9786c518a35a3857326.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1feb2a089b25879dd82e8e3a5bb98110',
      'native_key' => NULL,
      'filename' => 'modCategory/9a3c9f0899ec768c13f0e68a16b3afc1.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e2205eb1d9d64041919e666c586ea0bc',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/9a56fe284a9bcce2150b93eaeb58ecaa.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ab7ebbfb6a6fce8fcb86daf639e6d8e1',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/e2ca7da842eb3559694cd6b009d75c83.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '98c89db9edb7386612b6fcc62c4570a3',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/d993f17db725bbcdcc3753f4ac1b2cd7.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bb2497158bbac6a21a163e4330dad073',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/127218913bd1e6797eff4ddc55762f1f.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ec33fd943e70af4bcf1e60e976d17981',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/17981f7cf5be450a5c9c7f66e769f92a.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);