<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd01ec18452bf120838c5eba237780e86',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/7e963a838383007d21a11cd9b640bece.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '005f1b7acdc193e12e6bffb5546ff2d8',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/b578e74ce6f8b316fc814b853193bbf7.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a0bfd452c7435035fe4836e252f33772',
      'native_key' => NULL,
      'filename' => 'modCategory/7b0d5637e49e92470ec7dffb9b2ac1d3.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4e459517c170b1f3e6043ce1e6e8a24a',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/b46069b08202d5b692e40fc5d9d79ecb.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a7dbe5e494bfb50c4f088aae87118d83',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/2fd71492d12f52bd4a6e765378e052b9.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bb5c1909db2afe2b6568b06c391cf030',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/43623bdfa18e323cc1341da8dea80cc6.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e5437dee07f7be8cc5b277cae29f56b6',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/9f8c3132cee7d1c081991e126ca8336d.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '33b0d2c16d65a648ea3d5615e5af165d',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/4f37274fdce562732267cdf8ceca943d.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);