<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a743046635b6d28ba98387434d7064ae',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/e0dd642480279641a8501f20cb33c3ca.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e1cf203d039615ffb4d1f56d1e022d4',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/b4e441993c3b301e8321ea5708ad4473.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1778f13c93152e9adf516fbdcf585ca0',
      'native_key' => NULL,
      'filename' => 'modCategory/94276b6f045fc9aa35b9678ce8b015d0.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd011b1e1b3222b28ec1417258638a947',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/760b2c80aefbd6c87f0c97acca644480.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ec57dbe5349a55e73a688bdfd0607717',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/cf8998875a4622f9ec0f2c38029ea530.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cad3ae83d4a35057f08f73bc26f7d482',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/fec47de703db35537fc9f64e4dbe321c.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '60f0f29bb410d2425467a9c940bcab56',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/008ede3cbc24f42305cdc7de55a852b3.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0eb10488606a133c7a74f28da629250e',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/9749afcc4e9aba2deff947e2fb35bbcf.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);