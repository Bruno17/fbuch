<?php
return $modx->hasPermission($permission) ? 'yes' : 'no';