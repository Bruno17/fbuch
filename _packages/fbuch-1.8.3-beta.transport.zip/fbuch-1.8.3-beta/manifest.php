<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4ae6e2e0351b5c2265137e7a56c8c002',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/ee88a2dea1ac5443bde9525c32e95be4.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eee26f8f72876bc18fbb385e0d42d50f',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/275fdc4aa192b4f939d34bc7eff7246b.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f1bc85a8d72283791bdca6ea72b3ed1c',
      'native_key' => NULL,
      'filename' => 'modCategory/8dc59b03a4db4957f884116aa1b6a106.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1157aaee778c73bd7ce4e0b47b76497f',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/3e190b79ca8cc5eafdefb0c6ab7f2fb0.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bc42431d02ee17f8b65140b9ccc5c784',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/bef4b32599fc5f98aa52bd9462327563.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '901a4ab3d229ab86bda3f14d5736b5e3',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/a19d4058207ac2f073fb702267a3455c.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5925a164cb2a5e42f8e5dc22a4514ca6',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/e508cca64278082b8c0e65064930750d.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1ff01c158eb0f9c8528b52b875c0f812',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/9f1d0fb696f3b60751ab4717a8e2e12c.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);