<?php
require_once (dirname(__DIR__) . '/fbuchmailinglist.class.php');
class fbuchMailinglist_mysql extends fbuchMailinglist {}