<?php
class mvBeitragstyp extends xPDOSimpleObject {}