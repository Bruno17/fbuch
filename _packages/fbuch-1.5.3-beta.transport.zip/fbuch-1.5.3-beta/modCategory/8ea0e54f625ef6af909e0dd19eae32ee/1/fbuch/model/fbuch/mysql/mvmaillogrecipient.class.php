<?php
require_once (dirname(__DIR__) . '/mvmaillogrecipient.class.php');
class mvMailLogRecipient_mysql extends mvMailLogRecipient {}