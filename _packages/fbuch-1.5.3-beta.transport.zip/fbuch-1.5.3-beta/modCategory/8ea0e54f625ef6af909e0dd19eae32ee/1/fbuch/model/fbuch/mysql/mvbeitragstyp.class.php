<?php
require_once (dirname(__DIR__) . '/mvbeitragstyp.class.php');
class mvBeitragstyp_mysql extends mvBeitragstyp {}