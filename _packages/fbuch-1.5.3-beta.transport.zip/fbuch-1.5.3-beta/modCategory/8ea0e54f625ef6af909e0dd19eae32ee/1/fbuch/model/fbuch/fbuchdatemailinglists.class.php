<?php
class fbuchDateMailinglists extends xPDOSimpleObject {}