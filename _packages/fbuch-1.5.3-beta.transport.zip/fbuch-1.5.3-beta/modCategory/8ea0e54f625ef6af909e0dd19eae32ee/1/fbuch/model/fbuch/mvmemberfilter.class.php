<?php
class mvMemberFilter extends xPDOSimpleObject {}