<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'acfaeb6982bc79f92fab5f19e92b1be1',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/a55544364b7134ea19dc943d74a1f93f.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7f72fa4c7186962a4380c6d07e9fa803',
      'native_key' => NULL,
      'filename' => 'modCategory/8ea0e54f625ef6af909e0dd19eae32ee.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '377f1d082aad0e9bf0323c49a507df59',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/a647e8909841fda6fe75c22b5ebc86e7.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '76f6b195a2b5acf879bfd6e8cb55cda2',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/7eacc5bbc57f32b25aaf0002f882e1fa.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c70e130a4ddfb2798103d6a753e64599',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/bc5589985a8b7abf4072d8313b394f0b.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c0060f0c7fc702791defed0322d3c994',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/b3158f67e585a27affe0234bbe2d4a27.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '43efe000708ae6c443404e371916424b',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/91d71ab5698fa4cd99f28ef87d7630d7.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);