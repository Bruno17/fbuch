<?php
class fbuchBoot extends xPDOSimpleObject {}