<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchboot.class.php');
class fbuchBoot_mysql extends fbuchBoot {}