<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '56248247a576f79cce0aefeca55dd08d',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/f42fe7c0155a3aff7a59ca59b3ccf174.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '314ed8af90bb3c738fdd5402c5627175',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/9bc7380714b4dfa6a6144673332d89e9.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'aea8eddc9187887acb163b0922ab1e19',
      'native_key' => NULL,
      'filename' => 'modCategory/31de6e5285a6ec67c409dcf3f2433d75.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0e76962b5b716bce67357a13fc72a22c',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/a1b1bce138c7cffa5ea92de6c5659045.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c58239677ea2dc27a36af6600d6bbae8',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/ba942d8e87ef01d9e7e78f082688a5c9.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '794aac73cc69f0093321f970081f9712',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/b1eac7e4ea7d8cd6c3753e6b6a5d8188.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '15868bf5a63046001a31b8ce0a6c9d68',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/79da099b3503f1ea3611b9b540ffff65.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd73cb1ba5192d3499b8ad15a8c4cfcfb',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/5ee333dcab925877e4502991f61e2a69.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);