<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f65409fa287e5b343f7bb32d586a3f5a',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/72c776395669607e892de351e1355a23.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8707b8d04f0fa891a0e2a96918d061ed',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/647b8089a99421fe1e51c95cba84a612.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3aa11298a215a0aee79bc49525cd8856',
      'native_key' => NULL,
      'filename' => 'modCategory/eba8aa6e5e246deceb77b8c043bb87d8.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c2e8e56aacdc38fd997f624aebb660e9',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/6e32e3569b1d8e417b2c2ac1a9d586df.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ab3abb5bcfbfcb1d5d5f9d6b2f15d609',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/5cc45f0308112b1033bcc6c8d9cd9c8f.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2802187f64b216b9dbf20345a6ac4885',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/39def1b25fb0697b3f40204c4bea22f5.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2601b47cb7e479d0f5b9251c3f28d407',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/2e758f43680148d8514b0f41da47ec5c.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a27b3ee8312f914316dc81cc0d35d0fd',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/328f2ab9d09c86ab7b96ac35df3da250.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);