<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchbootsetting.class.php');
class fbuchBootSetting_mysql extends fbuchBootSetting {}