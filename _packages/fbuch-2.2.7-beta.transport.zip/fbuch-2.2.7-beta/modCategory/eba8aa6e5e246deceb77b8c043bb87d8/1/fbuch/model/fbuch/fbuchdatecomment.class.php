<?php
class fbuchDateComment extends xPDOSimpleObject {}