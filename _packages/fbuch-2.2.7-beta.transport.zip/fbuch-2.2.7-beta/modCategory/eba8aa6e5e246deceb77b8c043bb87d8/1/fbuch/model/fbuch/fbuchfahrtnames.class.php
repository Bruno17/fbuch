<?php
class fbuchFahrtNames extends xPDOSimpleObject {}