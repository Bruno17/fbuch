<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f3dabe85a6efc124e74348a44417c382',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/7705e268595e84e4d4a043d7470d21c9.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'edcd3bf324e2c476cedaad0460419ce6',
      'native_key' => NULL,
      'filename' => 'modCategory/d9aa3dcbb63b7f7ea994e428bccdcfb0.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);