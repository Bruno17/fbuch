<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchdateinstructors.class.php');
class fbuchDateInstructors_mysql extends fbuchDateInstructors {}