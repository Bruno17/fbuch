<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ac7d3ca648525b647745aca5fa6db792',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/1c13166a6193a4aa79dac423dfa84c6b.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24af12a3763ee75ada075ec92eed68c6',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/da51d168c69b818bca90737225793717.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ffefc2d462bfa8fe28694a9c13b4a203',
      'native_key' => NULL,
      'filename' => 'modCategory/ee51502bd774809f84cb2bd2b4ff7372.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '46464817fa22303645d34dbdfc332b92',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/9cab89c0fff3ecd1fdacf52aaeb57b3c.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '92c08700b8483577a559079ff5b8df1b',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/4ce653ec6b3ec03bf8ced9b74d1e9ea9.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4f8781fa221305a5340f95f7c943b7da',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/230c914a03ddf9f6cdd0212e2f358a6f.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2df341481043d53654f43b7d8419c48e',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/d13e6ecd797c6b10ef7742edd57283c2.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cd27727a1261370ea1f62335374ef078',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/9521823119f3f8f8c7e7e767c5f995c3.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);