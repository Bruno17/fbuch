<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '65a7ca8a3d0b08697d99eb30d53610b9',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/627323beed7fe032bd3b711bfe01578c.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b215ebb9f513c80dbc1357769492ad9b',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/f3cfc560524c375bbd009213f86e77aa.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1affa99bb83c37dd1d58c602d4e0cdb3',
      'native_key' => NULL,
      'filename' => 'modCategory/b6b0b1f55be325f0fe7ab59edccbb0cc.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd275b9d9f9b15df949f71a3626de7799',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/1f30aebc092fcc2d5b127986c9673c20.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '49661a3c83ad90bda13cbbd0d74396b0',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/88055979d05b8516db9a300d734d2d9f.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '620b7872452a079f358cccc7eadb3450',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/124395c3fb1c85a4ac8e656c8ceffc8d.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e60c5e156c39441ae6e1f51a34df9507',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/bc2d0ce01e2a605ad514514ec2392df7.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2659c1227994eb91c0cbdc552c7e4671',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/acacbca2df36356f4182c82113702b10.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);