import sample_template from './sample_template.js'

const routes = [
  {
    path: '/',
    name: 'sample_template',
    component: sample_template
  }        
]

export default routes