<?php
return preg_replace('/\s+/', '', $input);