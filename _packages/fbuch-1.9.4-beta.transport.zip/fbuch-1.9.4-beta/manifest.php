<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '72b2dec855a540e8f9ed3af03fd9536d',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/33892ab9fc510291d8c63d8ad2ce2866.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92aed1b0c80d616085428e47fd538ea3',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/6a766c99b957786714464ca2a0ca7add.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e104f22ff65e0e6fd405ff1db931396e',
      'native_key' => NULL,
      'filename' => 'modCategory/f5efdd772f142b7de9db1da3d741d001.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0eaace1ef8bd0f3e6cf143ea6f3171ce',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/82e4ddd59c0276606f25f1fbaa96a904.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4972cbd9d7a7e87109985315b812ac3c',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/1f29757a22abc283a70da80e26ddf3e5.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '007733e7903bbf792c5d9f61a8e00c3a',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/f0a27c27617e0d71251eb74116c5f1f9.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3a534232af521ee1f9549c2a9c4c5c2d',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/ac725f11b9aa5ede84a125c9d9e21307.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '587f521d3b9f5cd5b446af68ae505c54',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/398ffec4ce9c2917f956894bbd58c673.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);