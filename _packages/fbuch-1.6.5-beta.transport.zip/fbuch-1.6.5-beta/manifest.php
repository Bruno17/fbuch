<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '03e2960146522951ef946d8ead5f0229',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/bb120a72e5a11a84477350bfaae81e81.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88a69385891f9d3890f9cd85aae68a3c',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/90e78e9811934479f5a4e92fe3de68cf.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e59be5389756243179813dbdd4cab745',
      'native_key' => NULL,
      'filename' => 'modCategory/b1c865cd1d027de7b7e866cd5ebf1c1a.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '43d546d4de17776b6dda52c0b1de3dfd',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/574318e394203c5e55c46fa37e1e394e.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '16d657a1c7300d313b0c4c04ee42178c',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/627f96bf484e705873b9b5962e50deb8.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ca06975e2e063476c1460703a40de4be',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/586963e77c8dfb3eb4555749de655034.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '582dbb52cd6bf84358b86ea8a9602c63',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/746bb564082e76a96d0a8c4092282387.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5aa81abc77b3531c582d9a140a66c6bb',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/d592a110bceee599b98acaa98c51dfd9.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);