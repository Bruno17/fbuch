<?php
return strtotime($input);