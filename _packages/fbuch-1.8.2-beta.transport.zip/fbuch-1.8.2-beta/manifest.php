<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '00bc7028dbb13bf5287bb03cd06c6059',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/6ab542dc591db1dcec30b44b75b06db2.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21b2ff3c0e0d7a9e92e634d826e795b1',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/4c39ee4d6a94a4e4adafc86d336c549a.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '72584b6690d5002fb77e15a03a35fa86',
      'native_key' => NULL,
      'filename' => 'modCategory/59c3ab6ea03fbda89cee877af063dd35.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '29bcfb96ecd78309490ab45a7c2fbeb0',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/f54405e69b2c9aee2c2458c1f6dc32f1.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c747dd6c19d742d72707861e30181664',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/c1c34acedc55e50aeac1d6d557468952.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '059bda52065bfd5f7f453fba8710b5b5',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/0970c4fbd946c8db1851def534784fde.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1f87ce1065522532bd22f04fa752cdef',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/c7658d56a203dad5f62a33313a15903c.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ad86cd65d406b9f79af644446d98aa1b',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/3d67ec945eaccd340ebb1f300251b157.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);