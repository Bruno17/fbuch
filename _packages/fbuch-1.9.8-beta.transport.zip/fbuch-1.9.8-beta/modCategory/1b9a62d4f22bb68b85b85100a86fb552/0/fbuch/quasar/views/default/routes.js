import default_view from './default_view.js'

const routes = [
  {
    path: '/',
    name: 'default_view',
    component: default_view
  }        
]

export default routes