<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8a529295970a7e533f2cd73090f33c87',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/8b5ed2f9e7dd69a60105fb3a7e4e39fa.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a93c6abc6ff336a562035186f2c4b02',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/dbab5055c5428409f3a399eeb5b3ee18.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f083890a5234a9f8f21201f9a690b0f4',
      'native_key' => NULL,
      'filename' => 'modCategory/1b9a62d4f22bb68b85b85100a86fb552.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9f38478f36c3d663f2833d42be8962ed',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/f59f475eeb003c517bfd1e3ad4ea0e52.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '67015c25d044da9852f4707267ffb798',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/b92ebd29d27434640a515de9a1fed32b.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '45bf895822b19fa88063ff9d19f8aade',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/29e5764adf23b53e853ae73b656ff975.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2a28bbf4594f82669992439b2c655d8e',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/1945b1a8ea15b6359283e1f597328b7c.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1510eb3a0433b2493e0bac8b31939c8e',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/e3714015e1ff8586329818483f2da0ba.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);