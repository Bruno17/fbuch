<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'fbuchFahrt',
    1 => 'fbuchDate',
    2 => 'fbuchDateNames',
    3 => 'fbuchDateInvited',
    4 => 'fbuchDateComment',
    5 => 'fbuchNames',
    6 => 'fbuchFahrtNames',
    7 => 'fbuchBoot',
    8 => 'fbuchBootAllowedNames',
    9 => 'fbuchBootComment',
    10 => 'fbuchBootSetting',
    11 => 'fbuchBootsGattung',
    12 => 'fbuchBootsNutzergruppe',
    13 => 'fbuchMailinglist',
    14 => 'fbuchMailinglistNames',
  ),
);