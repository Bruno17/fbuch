<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b5879bbc6b81beedd5071de34ffd7b7a',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/b5e913a4043f413a407c0ad6a8e1cb59.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a50b85b3bf0fa4b9684b23cafbba0d13',
      'native_key' => NULL,
      'filename' => 'modCategory/72ed2bc1e016cd5cdc64baa3df18c350.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);