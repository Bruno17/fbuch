<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '01514e5e1b3508e2b435623583dfed55',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/d5cba9380512fdde2d708c0d17dc244f.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '515838429ef6f90c3204f2b9b500d748',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/6cee7bf95b382ec8a78e67544ec1320e.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0f9a6e9242ef6fe19172bc525151f629',
      'native_key' => NULL,
      'filename' => 'modCategory/bff09325c3dce65e115fecd28a1d784a.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '05d76c23d69aabe60fb131f6da8dccbd',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/498b3354deff10a943571470e8ca9647.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bcca9a4d01e376d87cc7993331d1080f',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/612b14c830d5df2d615e30e2b4e97df8.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '86010e01c7c3dad02445141bbf5e7cde',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/9befdd6fcf253fe9c7b0eaab27100730.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6ceacc1950e24b2ec21887057eccf852',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/43cf3faee3ce07d0ae7d4eb4f345c373.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6af839937b16663de521a82373b11935',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/39981484324d05ba3068b550395ff6ed.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);