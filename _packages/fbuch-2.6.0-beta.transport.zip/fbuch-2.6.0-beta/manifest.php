<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fbb1742e9f8844393be1869d3eda6749',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/69dc279409dcc1eb85e142f35da7126b.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e9a25ddac9e39d81a4ad1cd3c0b6738',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/bdaa7e8fcd409e39a0e8c99ea02e9a9f.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f5b0c063d8b0b6c6044055ab0202e1cb',
      'native_key' => NULL,
      'filename' => 'modCategory/e1fa0bb4522dfdb186105f73ecbe2c5e.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '207b8848b15ef5a87135a4e49f742cf1',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/3362d2b5b1112fc67a6d3f84049e1f0b.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0d8e99fc603af532a22f3621415c62ca',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/0b4eb06e2bdb4a6f4dacb83eafed6db6.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '020ab1576c8f62dd0f7824c0c3d3af56',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/e19e8b4179b2bae59cf47cc35351e5d5.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7dcbcd8ee135fd064e1dffb6cbd22f10',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/6e543432bc489602381b1d931a6bb894.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3c2f36376f5466a17123b65971781f68',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/8c13926743222aa5eacb24b446bf2fa3.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);