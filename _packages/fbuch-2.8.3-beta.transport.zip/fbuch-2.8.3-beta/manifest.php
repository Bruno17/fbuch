<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'eab6334663c0a27507fe7efa2273f8c2',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/6d281f5b3978182abaecd2f77341d7be.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51f4ac8ff031316da55840e875008945',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/6b246547399097fa4e1dc3dea4e39f94.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '670db1233f49ff157f88323b5648ab9e',
      'native_key' => NULL,
      'filename' => 'modCategory/57fbd948df39a277a8e4b9d72173f955.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '00b5b6e3736403c233db31b4f9d5509b',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/566fd28f6d279bf99e8770945833471b.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4508bc8894e9b7b360ff034a6c57805f',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/c3ffec34d3ca1c5ab3b9f75e6e63c8ec.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '90ad92a45c88606572942ab4bfcf54d5',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/6ad3f4d988ba6eff31a99f2f6bbfe0b4.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fcd598c0837eb6b77ead7aade6e869b0',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/2f2886d2f886cf5546a18be69d0f052b.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2c899b2d179d4a1ff704b114b96e9fae',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/a54d2a81b88933f8b7d048525cae69f0.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);