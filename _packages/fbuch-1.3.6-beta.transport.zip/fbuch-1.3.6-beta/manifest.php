<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6ea517ed334f520b254b8017993f993c',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/3b4e9885d0018b88b0655a7bccc9681a.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c7992e926aee9083fb8c83d6c83e8b64',
      'native_key' => NULL,
      'filename' => 'modCategory/1289d82045c67a77bac022f442905063.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);