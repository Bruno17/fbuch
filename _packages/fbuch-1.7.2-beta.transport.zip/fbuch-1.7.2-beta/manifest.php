<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a1ada59781a24e6c32d3263d68ca661b',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/0fc786b9aab6e773d4374e85a0a706ae.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2de273b27b5c9fd92220bcbf8067bbc0',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/548dab90aa53d2166ebf54c79b4fb2ee.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1aef12a47758ca90be194b19ce74cb9c',
      'native_key' => NULL,
      'filename' => 'modCategory/eee0f64f08c5b4d99429cf91414ef608.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '94cf234bf8bec200f0ad8538074ff3af',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/4f80a31d6da6de7f4fdf0c5bc0af3302.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a6385496cec875e6e44d183bcddcfcd3',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/2cc2b02950e15e092efbccd9af3f3998.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '052e5d78d04890b6617351f97bbd491d',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/8d36ac397678144986f4c2861d6b68ce.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0e54c8df4a40c710575ac0ebec400efb',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/04453689837146d6e701b710f788115e.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '667cbb6eb61f6249fe7cda32eb2f0ece',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/6cccb998052de271c67b28344fbea4e1.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);