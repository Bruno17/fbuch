<?php
class fbuchBootsGattung extends xPDOSimpleObject {}