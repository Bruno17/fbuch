<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '48bcf4f0479b7191ff2b13e226d26e4a',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/782e35918707c449105d94153e87ee4e.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad87f224f8692736872b63e319b526ec',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/d4197510a8716cbd4f945f744c5e575a.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b3b9f219a3f1768fc8ab7b0f18f956f1',
      'native_key' => NULL,
      'filename' => 'modCategory/bec299bc8a3a3a465bb47fe9235b5682.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '38edb7ccd7af1c69aaae3374bc730e5d',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/4663a83cce76904ac6b2d95a0d9e0f24.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'db93905f8673406683498345f90e4178',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/42ef8b9b8dbfc51f0cb6a0351c3d2a45.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '04f18c0606e456fc4fe13144390e0260',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/40b494849ef35330b46aa9e1a407fc33.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b67e2a714a69aa496198812140279b6b',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/5fb8de74197e3fcd19494009f8f068bb.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'eab1838611a89b6fcdf161ad06cbe56f',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/5440c8666a70d7fe45c41f2c7fa58ce9.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);