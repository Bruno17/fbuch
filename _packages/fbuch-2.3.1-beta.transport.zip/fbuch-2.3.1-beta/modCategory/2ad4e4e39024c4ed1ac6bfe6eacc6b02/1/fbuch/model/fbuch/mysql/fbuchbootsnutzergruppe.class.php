<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchbootsnutzergruppe.class.php');
class fbuchBootsNutzergruppe_mysql extends fbuchBootsNutzergruppe {}