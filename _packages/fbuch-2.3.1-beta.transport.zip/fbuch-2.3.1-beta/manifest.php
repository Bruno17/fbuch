<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '27e745c4bebe997339cae3e551baf378',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/1a6f34f979ace0cf2e43236d5f141373.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '655427ec38c7191fde92cf1df02e18bd',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/ea686a742d4de50eae049afc43fce71e.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1dc235119a48a1a21746b896b9e152cf',
      'native_key' => NULL,
      'filename' => 'modCategory/2ad4e4e39024c4ed1ac6bfe6eacc6b02.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b8445db1324a1f7324a8ff3c26fca3dd',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/abb1999a5e46823507e295450a0c0687.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ca1218adfe87203ceb4628305448f452',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/96df154adfdd8e4c90b1500bfb51203f.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b9e7304ea783ef541011b3935230df89',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/099bc549f53bd9ab3ad2fdedc2a6b798.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4a217d716013c870077e89bbd45d40b6',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/f6cdf660b8bf399f446a412a24eec6f6.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '09e25dd8a09e57e56e5e7055229d3974',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/950a091f2c3a988fc9a0431c2f30ff8e.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);