<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9e7245667b543b3c2c27946b0a95c99b',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/eaa1f4b64bfefec8741b6104a9754367.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0f9fa9a9c8ab72a8644ff67290cf5317',
      'native_key' => NULL,
      'filename' => 'modCategory/ef87143163fba092d458081e2ad02e69.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8a11ebef03b88334fec08dd4b8da170f',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/9e118977a403b65a4099834d1c6e25bd.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '803cbe19b1acd2d995ae5c963b2339a2',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/bef02700f560e54207107ec4be1f64c9.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6d70107c0af312abaef60c6e802cdbf5',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/f85a433d47723206d8a8665d545b087c.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a3f9d466e6489b48efa1dc914e0abedb',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/8c1ca04cfd71cb03418feaebaf43abce.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8659adfc98091bbf46b0677f7b77484e',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/8198b68e209d7d44a378030153929bce.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);