<?php
class fbuchNames extends xPDOSimpleObject {}