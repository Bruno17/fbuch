<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '49e6d12b08e23fa8f70a6f4b4f8fca62',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/0eacc68eadd8c97d8d23df38e410b740.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd9326998ff2be6a1d6254607b006001c',
      'native_key' => NULL,
      'filename' => 'modCategory/926c584680a974a1c7491f3437537c54.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);