<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchnames.class.php');
class fbuchNames_mysql extends fbuchNames {}