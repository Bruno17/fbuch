<?php
require_once (dirname(__DIR__) . '/mvfamily.class.php');
class mvFamily_mysql extends mvFamily {}