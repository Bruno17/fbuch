<?php
class fbuchMailinglistNames extends xPDOSimpleObject {}