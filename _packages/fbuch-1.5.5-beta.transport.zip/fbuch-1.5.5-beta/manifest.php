<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd08c3b67db55a174df3e5680b522e7d8',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/7a8619bae569339ad42b7deb8a344624.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd14575874b133db494c4c2875a2e8adb',
      'native_key' => NULL,
      'filename' => 'modCategory/260585da60f7f1eecbd893c0203aac8d.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '575bdc8d69fa25d80b50b22e5ad5ed74',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/2b9f7c41dc6d5e00838c834a602e0314.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b22586f3a77b0356ab73976e44f5f97f',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/1c52bd92a149358499631c952cd6d74e.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '01073f923a07fd2593a630efe386534b',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/b42b1c52e63e444e1a28baf715774e7c.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ecc18c802696dac58aa8bb506fcdb9ba',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/5c55fac94bf9c1c89af2ae49b891a930.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ce81e6f1254a1111e5b4c2535c2aa4d9',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/e2580d4dc2d2dd3d00f115ac821dd9a3.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);