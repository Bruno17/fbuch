<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '60346b803bb36acbb80c8d27ccf033fb',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/c7f79b704e92549653fb801a8001dfa1.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '213a1ebd9ce6a712fc882cefc1047349',
      'native_key' => NULL,
      'filename' => 'modCategory/4a8a72e2b7de4df299534c767735c695.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3fb8a6c433e498ac77996da9002eb33b',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/a6181ae736650ed761f1bca8e703601e.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'eb72c328b7bb740c0ce3e5dbdf511bef',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/65e69c93586a5c1aadefe0e6d9eff7a6.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '89a23f6e0a62c2bae90eff510ac5f5f9',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/c380145a2ca2bf02ea0d4c627a3fad6c.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e5ba7e8216b2c4ce552449e4513d8616',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/4e9b7151a5af4546f0428474a1df105d.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bfffcc53613f6d8e94fdb8d180c561bf',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/d3c3777dbf28260a3a252f0220b7a9b8.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);