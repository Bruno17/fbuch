<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9f3debd2371359f7cd5a036a0488c164',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/deba497a36dceb79e145f2160861bbdf.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71ea0028a3255cbca085825057d24de4',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/f35175748fa1cda2cd45e54a712fa615.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '62481262b78dc3b9731ed4e30cb30252',
      'native_key' => NULL,
      'filename' => 'modCategory/27fd4517925a89c8a575aeb2fe8ba868.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '966cf1de6396a2851e14da94015ff201',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/696e94aebaac92a650cbf314c0e5dcd9.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b3900781d743da19953af5eebf7aac20',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/5a150dfa30c668f0923e2ae5da50974c.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a542853d35f6477e0674414c85e68cf0',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/46f3322fb2ae17a291e637c6bb516106.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '80aa65e206ad9a17dea093956c5512e9',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/b76788d529331859e5a344958c99c09f.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1d8beaa3884a4d3da9d6a1ed44c91097',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/d6c87bc98115fddb043ec91ef19e8d20.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);