<?php
return strtotime(strftime('%Y-%m-%d 00:00:00'));