<?php
class mvExportFilter extends xPDOSimpleObject {}