<?php
class fbuchFahrt extends xPDOSimpleObject {}