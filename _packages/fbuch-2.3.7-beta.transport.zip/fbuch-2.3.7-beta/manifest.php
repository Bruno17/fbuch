<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '62bec0acf4069a94bcc8901227dc2b12',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/22826abab560782b6c407af9faba4c34.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b91aa8158d82aeb4c740fb0dbcc97647',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/75823d7fbca7af8902fb0cac7c0ae5a6.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'aab189134a7c69be88ef2cb5e02d6203',
      'native_key' => NULL,
      'filename' => 'modCategory/2eeafa9dfdc4d4551cddd99e09a79bba.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b10c95a5dd864d5f549957531d391bba',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/37bb8e1561ce26a12924082a4f0126c5.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ceb5cb39d3723d28841f756bb79e8be0',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/dde2484daa66fa886f9eeafe74aabc91.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4b1d62fd8076f051164fbe975cc4572c',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/70192eb2c7b468653e6f2d1579ea192b.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a714cc372f762c3377c48d5adfcc2e11',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/de67d787ef7d62b46523a221b97eabd3.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ac4fc135273e71c5d1b112d09f36050a',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/6c204519af1e1eb8528a96ae626718cd.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);