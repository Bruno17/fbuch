<?php
class mvDoorAccesscode extends xPDOSimpleObject {}