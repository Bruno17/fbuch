<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '51ddf544917802ae539cc930c303bc8a',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/5c15b67232c91d04f6e408ea5f7720d3.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e16e530f54bf71d651bd984bb2193151',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/1b4f713fed3392949b839bd8b54afa56.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c105a772f7d68aced8eaaa1055cddb2c',
      'native_key' => NULL,
      'filename' => 'modCategory/70bd1add8b7e507cfe4e3ac73a7c81ec.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '349bb231c5ca16d11b2a8103a2ba2d0a',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/1406a2dde3122a5bcd101c1e89a00c8a.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a436fb7672ced0d17a6bac0f501831d6',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/65969203afef63a76808e3a524da20d2.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e532051834c97b32955a571d45a909f9',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/6024f82b653b4c83a581c5c5f9a5eeb6.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7514c69a13feeb22e76207ddc57f2f87',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/6ac52e2961e0c967238485922a3642f3.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '00df89e12bcdabfd41e64bc6c72a8eef',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/cc27feb1e090b3a28518b053c5e4ac2e.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);