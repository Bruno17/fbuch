<?php
require_once (dirname(__DIR__) . '/fbuchdestination.class.php');
class fbuchDestination_mysql extends fbuchDestination {}