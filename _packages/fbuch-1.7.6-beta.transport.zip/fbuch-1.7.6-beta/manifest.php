<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e496846ab4ccac6ff301bf9607900762',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/1c540ef6b8df29e40dac3cf7be3f7c05.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46e687161d9f2372ee6e800d5d2fd6c9',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/74efdc8ec2b3b06173ca4e0ef4f7fba2.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '16a437f07131504f662bb287569dc02f',
      'native_key' => NULL,
      'filename' => 'modCategory/556fed0ea8f18f918ad5748c8791e9c0.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '27edb1b6feaa7638befa79fcc1ac04c6',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/50d1a4bcd088a61a615bd9db88289ee4.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5ab036ccfffbd401fb25bb3adb65d7d5',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/7f3ed3a83b17b0564630eee52d7fec25.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '071f847eb14399639f16537508c468b7',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/0f6bce1ce354da49a813597ded757bcd.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '24a249a4f1bcfcd24534bf80b76090ef',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/adfed95b24e6b627d914bb709dfb2241.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '50b84a3f292de4100af4ab05aa7c7438',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/d52be3991644d0ad9364c686cd47537c.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);