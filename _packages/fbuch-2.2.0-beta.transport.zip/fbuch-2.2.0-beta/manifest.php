<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0ba4591d372444ebe12c7f7f1ee634a0',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/e111c27ed66ddfe5bb133f3c8f711e55.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a6b8622ffd8bf40a9a6598c3badb9fc',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/6470a1a1b4510c8b3cad29b7d493b9a2.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '38d5b7b8ed2ed31bc4d5375c60a1d0c5',
      'native_key' => NULL,
      'filename' => 'modCategory/20d412bf33b4e6e3c5fa3202c42d2514.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bdc4a03ec6bb602a93a4042de36084d2',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/9cd97af2b735b1c9d53c6d870dfdc431.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f29029efcfb0356cdacf9603e54682ed',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/6601f1277dc40726d7b61f58d4242912.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c509ecaf844666d9d9835a539fb302cf',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/b77312229b219bc3848b98f4b521044c.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '274601f0c0d3bc04c61cd0aa541e09df',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/0c1164eb3f9a66c54d99bfa6fb83481f.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1a7cc7526dc493475f80f854b0d15d64',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/9c7b4573ea95f40abdbfa0b8c6cac014.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);