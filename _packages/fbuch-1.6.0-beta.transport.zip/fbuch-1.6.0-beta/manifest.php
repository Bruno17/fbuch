<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f5380829c845e4928379ad404f6c0aeb',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/a0d634a6325a51b42078a7f4e4d9120d.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1c7e091768b2cb67a49e5a48756c79f9',
      'native_key' => NULL,
      'filename' => 'modCategory/baf6f36b8a2bd34f0fec30a6b67c0491.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '08ada08ad39d7f3302488b76efbcd7b6',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/09250f2d1c3294cde61fe1617e2eb4ec.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7fb3bb88a73268644f6f5d1435e3186a',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/ab0a6f89fb21155f93f5c07b9cef0f7f.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0775311a81872b7c171db2240ecea42d',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/662479fd66e0b87c6589f1f7303e4f72.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '366a27c6a55f54bbc11d9c905de7fb51',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/d250b6d2e9dd513611f9bc35388ffb0d.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '214871bee823643c15b3eec85c2c50ed',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/830a205da9950efdb667eb4bd2e2dda8.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);