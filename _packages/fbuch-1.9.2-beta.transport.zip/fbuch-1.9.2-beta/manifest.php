<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6b5c08b631aeefa1364a058057cd908e',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/f77561d5ce46ed5527de203e0563651f.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78d3576621e54d69c8a586e744fdd4e4',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/f04000fd319ba6d3079bd1c3b829b1bf.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '40e9d5fdb46258498f307a68a82e7a87',
      'native_key' => NULL,
      'filename' => 'modCategory/ef59a7b5681992dc78df148100389ad6.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'dc2b33dafb5009617956013a9a05891f',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/244fd6688a459b7a3390bbdc67bad20a.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2350f499a7f11090747e1bd785f6fcad',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/21bdf9d8f1bc856bf0def5560deffca5.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c0cb42db5d7c60d00ee58b2dc5f2a003',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/44c9ba0260daabe22b35bd84313a5168.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '888ff4628f00c955fe8a86318257145e',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/48a4a3470131a4406835e17a5e89de5b.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '41bbcbb0e227d8bd724ec702bd34c93f',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/2fb5a2938b6ceef227accf4f2b827c53.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);