<?php
require_once (dirname(__DIR__) . '/mvmemberstate.class.php');
class mvMemberState_mysql extends mvMemberState {}