<?php
require_once (dirname(__DIR__) . '/fbuchdatetype.class.php');
class fbuchDateType_mysql extends fbuchDateType {}