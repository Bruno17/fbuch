<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6e17f428d15674dee95c046c22eb6c49',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/4ecf46b8b2b0c1a0572ad2a138e095d7.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '136ce74f066b4d0a56d4b00109bec0c2',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/1f76ba985e9407e9b6bdb02b99e22939.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '37de88cf675394ecad446be86da1c8ce',
      'native_key' => NULL,
      'filename' => 'modCategory/b8c7bb3e05934605c398de73f7ff6e81.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '27a563e48b0c112a3d85472bc808ea44',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/81bd1b1b8f9475adfec1407b0e41229a.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1ef52d1399f95ca9a2474013fb05744b',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/0eacb9a7b9bce215dfbf42c9c1a6ff77.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9fd3c8fd56cf1ccce9fff246c5875dc3',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/65dd3e2b3bb6dc277b56ea882f0ab34c.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '22a811d2b516eb9382a5fd0be89fe306',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/4a0f68759cafdafe7ea8caf2d5643785.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b8dbe26c8a1df21afb3b5463dae44ad4',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/bf8e3fd67e4abf3d2acf82b9067f45b7.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);