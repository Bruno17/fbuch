<?php
require_once (dirname(__DIR__) . '/mvmaillog.class.php');
class mvMailLog_mysql extends mvMailLog {}