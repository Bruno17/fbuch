<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '57d4078fe58eccc5a28c0f48be4f2b8f',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/51993286708acdff8d7d456090f284d0.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82a93141bfbb05415a124c533ffb006e',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/f72ffba8bc3afe1e7c02e52bd5ebe1c0.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f30e3ab15ac5147ffbf0b6c4e83cf1db',
      'native_key' => NULL,
      'filename' => 'modCategory/311b2d3d6bdd93e09b211adbe8bd03b1.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ae92f7dabafdd60d435894cb5cec2323',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/de58a6849abb797515bd9075c63446ed.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5141fb0b7e0a6ff1eb99d8ae021fbc75',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/5953540db6406c55580463a3bb627c44.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '11b478a65824ebfd48af9059030a41e4',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/abdd3a6a310faa87816645cae36727d9.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f1c84e4e3c6957eeae23eea38c6004b1',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/383ed844a585201f26cf1bf96816f17f.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3c344fcae1b6357f62a155aec7bb20c5',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/536b79b8e5c328457c3cdc5f44c72ccb.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);