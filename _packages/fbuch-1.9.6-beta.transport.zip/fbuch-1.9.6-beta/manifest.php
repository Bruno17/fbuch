<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '343b559709fddf143e851d8d9d5a5919',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/a2592dd181663d73b3bc54312884489c.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0491d75beb38e013a799dd73b3becb88',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/3b69e7aea9938995b9fc753c4cc747fc.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e3083a0f20dc6ca9a33251b7eb66d50d',
      'native_key' => NULL,
      'filename' => 'modCategory/d4d6d3bc295fe5c93e344e310d20c602.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd872eddd1d0a280f74491586e2ac1260',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/795bd3449ed8a67b145efa8427a68543.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a764db07aca90b1ebb82749db88cbdff',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/20b81ab13aba0862fcfea0e42632df59.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f5459aafba6ac24dd3be325c80466305',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/0850b1187ebce57e5bd81a78bdd4902d.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8e1bc057f3e279f3567a09d43c76f132',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/b4c6e38e780a1eceee7324cf7702986e.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7be8f4d1b49b594f98aadb06686899c6',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/0a3c8d91252d60d97b7bbc20fb371bab.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);