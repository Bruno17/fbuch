import setup from './setup.js'

const routes = [
  {
    path: '/',
    name: 'setup',
    component: setup
  }        
]

export default routes