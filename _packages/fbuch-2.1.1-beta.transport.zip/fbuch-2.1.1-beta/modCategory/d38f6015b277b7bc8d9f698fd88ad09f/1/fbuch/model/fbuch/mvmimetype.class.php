<?php
class mvMimeType extends xPDOSimpleObject {}