<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '86a6b131cebd77c30b057a1c6f6622ce',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/ceca6d343c49d25e0516749ffff08ef8.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74f2f90578de65fc3223611af8c80fbc',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/962087a67b33eae1b768ae441472407e.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '39974f0d4b7f2fb2ab66083bc2791277',
      'native_key' => NULL,
      'filename' => 'modCategory/d38f6015b277b7bc8d9f698fd88ad09f.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6da70d46dbed8244a85d78d837c805ae',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/b3c9e56100c522f6aa3d0f734f87ccdd.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5e5926bca6244fe4074f28319344cbe3',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/83b6b74e0273073faefa517d7ffb0ab3.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8c1ba3d48ebe9af1102c7fa13069ff1a',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/169d8f54a2d9ced37ce174db656fa9af.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'edfe3f22928bb5a2acba108abf253cdf',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/6de1153b0bcaf6ffda9199b0f9816b80.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9afbee11bd7bc27c03cc86a58a6f43e5',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/5cf62fff033610ccf59b42a7210c6499.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);