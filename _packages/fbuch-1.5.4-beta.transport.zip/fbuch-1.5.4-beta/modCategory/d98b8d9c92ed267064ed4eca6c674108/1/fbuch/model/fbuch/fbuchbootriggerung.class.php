<?php
class fbuchBootRiggerung extends xPDOSimpleObject {}