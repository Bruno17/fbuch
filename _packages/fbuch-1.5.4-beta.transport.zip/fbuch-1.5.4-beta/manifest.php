<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '78eabb4d1045c0d1e85d024fd2b375cf',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/398a23325526ce0fe6e362546e891a1a.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7f443ac2705dd9c65b7e56c45f67f96b',
      'native_key' => NULL,
      'filename' => 'modCategory/d98b8d9c92ed267064ed4eca6c674108.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6275dbcacb064fb99413892bcf44f5c0',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/be37c1cc3533002884266d4408a443c6.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '877ea155944f246373d29a6c0e8a97da',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/f335b13bb8f4da3dfc98cdc7ed5fe4ea.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '36a7de3233f330e78e33b899eabe3f1c',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/5ca34f2fd8741a9bdd68b0e758598e55.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8e6098cbaee907b428bd679609143744',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/9e08e5938bc8ed0b9cce7cfa82923294.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5b4aed35e4cf7468040bc23ec7136e72',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/060f1087be6d1301e49b7c58b95a0f27.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);