<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ebdb8f5131cb62b7c2882433657f9620',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/834282d834ac2a39a8887506238d9ace.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54dbdb29319a680ec852a05b2b31b40f',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/645f2830a31bf0b285935b50c4647dad.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a73ebbfc1830b01ff20b66b3257814ac',
      'native_key' => NULL,
      'filename' => 'modCategory/18519bb0d792f8fceeb82d8e6353f9d3.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0a98ebd14619326922321e9d909bbb4f',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/83d1f59af3c94af1d672f0feb1d16de0.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cea5c348e0dd9d1595e92a75bd29fd60',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/a7c6bc8c52c60c1d6f578606390fd4bd.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '397e40e792f316daa8dfec60e7d1e7e0',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/1f93a4803e580187a7bfd761c57e11ad.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '50d2359670b35c6a9398ebeb391e55f4',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/fd64cb951d8af33ea86e4458331deba4.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3a6ceb087b38278296ae31a9ef274aa3',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/8050572dc990c3099d1038f0a87d9bd7.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);