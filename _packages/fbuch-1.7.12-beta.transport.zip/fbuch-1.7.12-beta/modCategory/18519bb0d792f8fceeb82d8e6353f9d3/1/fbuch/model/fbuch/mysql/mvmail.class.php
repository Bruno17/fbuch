<?php
require_once (dirname(__DIR__) . '/mvmail.class.php');
class mvMail_mysql extends mvMail {}