<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cf75b476adb4a893f0f1003496c4b80f',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/3770a3fc4380dc077156b0edf0b172a5.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4d2117cdd2677a6a175a8321f5151f77',
      'native_key' => NULL,
      'filename' => 'modCategory/e1e4c8110d5814bb10c23f692aaf48f2.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);