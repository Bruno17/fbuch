<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchdateinvited.class.php');
class fbuchDateInvited_mysql extends fbuchDateInvited {}