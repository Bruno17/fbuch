<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchbootallowednames.class.php');
class fbuchBootAllowedNames_mysql extends fbuchBootAllowedNames {}