<?php
require_once (dirname(__DIR__) . '/mvmemberrolelink.class.php');
class mvMemberRoleLink_mysql extends mvMemberRoleLink {}