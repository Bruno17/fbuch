<?php
require_once (dirname(__DIR__) . '/fbuchbootsnutzergruppenmembers.class.php');
class fbuchBootsNutzergruppenMembers_mysql extends fbuchBootsNutzergruppenMembers {}