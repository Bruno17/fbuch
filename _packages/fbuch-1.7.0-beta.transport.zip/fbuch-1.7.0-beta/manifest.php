<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b02c5e40ad5b2262119adb587eab350d',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/b61f37529de7a81f62d266c6048a1361.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34ae4afb1f431c35ca90da156a0f9d38',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/4d249e7c5497f818a8f63652d0d2cbe9.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c21f245a50c68aae8902ea2797337f5d',
      'native_key' => NULL,
      'filename' => 'modCategory/bd10e1eca16fb4a5727b29aab7915280.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5cae455cf327308c4f03158ce9062b28',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/c80e517f7ba4337bdcdd08c33cd40f6e.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '35a2589e4b58545555fa19b6b741e14b',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/6578f62846858ec19cac83d20c570440.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '75b720517e13ee6220465edfbd9630c6',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/e2d0f025fab6440e63f1e9ee9836d042.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b3605cb41946737b77823e80730d1f78',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/1906b2e57cbbf27f73e8a78ee5bcfa2b.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bef58e688506e763a0af3084a93c7cb3',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/02ae9a76f74c0a605da49e488f9f7286.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);