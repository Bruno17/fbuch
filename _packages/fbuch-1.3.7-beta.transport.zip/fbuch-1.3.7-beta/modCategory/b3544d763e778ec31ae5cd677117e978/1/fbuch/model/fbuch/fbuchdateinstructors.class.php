<?php
class fbuchDateInstructors extends xPDOSimpleObject {}