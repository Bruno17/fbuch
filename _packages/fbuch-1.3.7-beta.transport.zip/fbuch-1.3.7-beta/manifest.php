<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a989657270fa2718079e3b1308fa499d',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/8b1dc5db3d95b1e44903c5fd08a0eb88.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cfaa4fcfa6a3b2b4a81b05fffaaad3ca',
      'native_key' => NULL,
      'filename' => 'modCategory/b3544d763e778ec31ae5cd677117e978.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);