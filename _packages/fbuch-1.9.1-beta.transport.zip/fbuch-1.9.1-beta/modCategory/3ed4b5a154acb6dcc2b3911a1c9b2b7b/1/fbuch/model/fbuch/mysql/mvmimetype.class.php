<?php
require_once (dirname(__DIR__) . '/mvmimetype.class.php');
class mvMimeType_mysql extends mvMimeType {}