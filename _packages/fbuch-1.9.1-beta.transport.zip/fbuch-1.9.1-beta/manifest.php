<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9c49d12136347f66548291bf35b54042',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/8e6dd0cd3276afc0f00172a03a411f64.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db8486ab3e573695e2fb128142fe6c04',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/dd7623bef0782a3aedd7da8c699df16b.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'dd054324c372adfaf3638d565b34edff',
      'native_key' => NULL,
      'filename' => 'modCategory/3ed4b5a154acb6dcc2b3911a1c9b2b7b.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6b1b5ddd96fad104d3e9646e27b95edf',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/8e13ad5d4d671c70cf3bd0f3aa59a799.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e457a342221469c1c347a6469a863fab',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/b5f26c41325280f9d116ee7b65396d85.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0e0faf882088268cc306c3714af0f7be',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/9ec2e272f7e3833708068f4e97976417.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a4ecbff35ead577752dcef960db10f86',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/d7188e4e8e2d747fd9c2a0449959114a.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2dafa10f6499eac39370728b0df65739',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/40c7ea255398ca16076281249f8ac4f3.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);