<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd9d2610c49aaf3c0012032dadb177139',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/947365b46066e1f9b894c0448147ebbc.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2be89b266d832ec1d00640870a922421',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/d837fbc15a41b0edbb9eaeb73e09ff36.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f804d8159ecbe60fccbc4926b17d07c9',
      'native_key' => NULL,
      'filename' => 'modCategory/9784fd7c2848864c574ede2019814a06.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'afc922f14c46e37ba5590489be8cadfe',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/4acbf4d0e9f05eb8ba9c55add79a5a38.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1a97b8edb56829ada29a85d54fc2ef55',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/d6335e1e1c11619378154aee9c87d65b.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3a5f2d5012a8410a33ba9894cab75f83',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/41d130afdac863c6374c87e3935e1fdf.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a810837ac0b97a21c4e274b786dbe94a',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/180489e598251b87ff2d576c2e4e2364.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e3c9a420c9cbcbd792c367de7df558fd',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/0088a0089cc7ce9320fe61adaebd62bf.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);