<?php
class fbuchDate extends xPDOSimpleObject {}