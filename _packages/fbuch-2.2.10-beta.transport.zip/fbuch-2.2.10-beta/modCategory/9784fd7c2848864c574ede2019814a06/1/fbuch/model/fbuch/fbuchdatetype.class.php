<?php
class fbuchDateType extends xPDOSimpleObject {}