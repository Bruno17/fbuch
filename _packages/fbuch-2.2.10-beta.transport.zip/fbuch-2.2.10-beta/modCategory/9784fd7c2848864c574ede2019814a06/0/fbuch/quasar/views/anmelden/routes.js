import view from './view.js'

const routes = [
  {
    path: '/',
    name: 'view',
    component: view
  }        
]

export default routes