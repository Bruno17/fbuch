<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '78acd421c21ef2a1b3b99e63f1e69339',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/0c71b05ae249535d6e8db4543416347e.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '191c16f5558ee593c085886bbc9bb754',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/2474f3e845c767cf4e3cd71248d5e42d.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2a35258d9c970e95086bfe288652627c',
      'native_key' => NULL,
      'filename' => 'modCategory/bef57d6e45d01b9285769a927a8fde63.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'acf27cabaa34744f19b3d9bf5006f2a3',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/b1876700cc8b04eddd4072c2beacd2ad.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a297b6547e1544b88d8216fb3ff4c1ae',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/0ee060b7c728f154103a075532eaadbf.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '97b5484093e453c5dc512f372f3e8f38',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/c2be22d8984ed2e21ee105902639cd48.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b8722ae401a369bfcc41f68ffc5a502f',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/37b1e28c49cc733bf57746bc7aff3637.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6deb1f6886ef8ca5f88885d0bcfcdc35',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/58bcd7a879fa984861f04f7ed7e56ddb.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);