<?php
class fbuchBootsNutzergruppenMembers extends xPDOSimpleObject {}