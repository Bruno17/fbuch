<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4504ccd3c6b178bd58dc1b3c65e045bd',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/68a01415b797125dc4f3d82f52bbcdac.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5e613d7cba01058439a7195a65f6555',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/ff966bdc9af7c6dc1f8b17033d489cd5.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b738d59564b34be6ae17441a1f53f6d4',
      'native_key' => NULL,
      'filename' => 'modCategory/2a912ac143fbdabbc1a611100e652042.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cd01e056c6ac53cbbde246e1d812c552',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/b6e20f9b790eaea90e6c9c9bc524900c.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0efc9dd358a0bc1604084cb2f1482fa8',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/c8c25729961c0d307b815348a5cedf26.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6569925c74de79215b76371acb0205bd',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/634e01e1f39a219d16dc2a4a61670ba1.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fee81cb4b6810cf833531e8ca7088cf0',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/f43f9565ebf6f2c3ce691d49d5996c7f.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '38db17b105ccf637a998ac5ed9f76a67',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/293e9ad8f575678f59ebd86b9d751772.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);