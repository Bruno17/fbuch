<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '994bd2e046ad8f6027b0060d233ebb04',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/879a899723954d6c3b8a7a903445855d.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e6ab780604365f519c257b059abc8b1c',
      'native_key' => NULL,
      'filename' => 'modCategory/5cf1f8bd8aa8dfe69b3c511c475abdb9.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0e704db2b7f5f65ed03b356374257565',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/1914b36dbfea13ef5f166ea4aa64aad2.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '897377190aeacc32635aa7aa1417dc0e',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/21b1a66cae26ff578afb62d93c20baad.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '67a29ad9283d20967a94c91be5cb7487',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/0a7b9221240e7fe7a611222f7478c5d9.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1ca1452591c335bc145113a3fffc51d9',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/82ab51dedd1dcb3b14b94a9f6c329751.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cdee8745ec31fe0c291dae4635a0fe12',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/f202b493d43b4e3af38edfb8f0796ffb.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);