<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7873ec61137e98dc20098a002e5024e8',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/f9ec160fed0e591621b2f7a7d45dcdd5.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd964304142e691905ec9a68618c34d6f',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/5051587dca66df16130d234a768b9c30.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f2c0fafbd70486516f32376ec4ef113e',
      'native_key' => NULL,
      'filename' => 'modCategory/b44082119307096c46e978acda94cb90.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f880bc8c144c067d961feafafafe14e3',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/89e156488665e571784caee815925345.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '59a505f7906dde9d22d2b1c75f636f38',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/b6a3b01de0da467d3c51d05f2e2e6759.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a8ac035283c77110b9cb54fa739601f9',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/6b85f7334a936e1a88896d86850506c3.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b0141ba0e1496cd2643a6f14761d2054',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/f7aeb1099ebab9aa85dea03bd593ee31.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5ecd6e2c824bca3c11d1fa82bbf3440c',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/b683c925bf03f6f0e1d44ec0836f6cc9.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);