<?php
class fbuchDateNames extends xPDOSimpleObject {}