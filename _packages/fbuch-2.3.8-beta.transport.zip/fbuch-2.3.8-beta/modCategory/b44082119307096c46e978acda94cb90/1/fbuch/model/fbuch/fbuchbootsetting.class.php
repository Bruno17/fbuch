<?php
class fbuchBootSetting extends xPDOSimpleObject {}