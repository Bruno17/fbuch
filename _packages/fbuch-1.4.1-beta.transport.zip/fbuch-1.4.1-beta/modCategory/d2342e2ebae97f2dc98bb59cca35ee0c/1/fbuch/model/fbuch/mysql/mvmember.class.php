<?php
require_once (dirname(__DIR__) . '/mvmember.class.php');
class mvMember_mysql extends mvMember {}