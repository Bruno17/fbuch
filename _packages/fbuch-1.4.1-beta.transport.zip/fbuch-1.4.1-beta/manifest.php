<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8ae2f246ed40e6d3894b38dbe12e5536',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/17ce853acef1c96b8ded6a75783991c6.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a6f5303b94015eb5b7009a92ca51d22c',
      'native_key' => NULL,
      'filename' => 'modCategory/d2342e2ebae97f2dc98bb59cca35ee0c.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);