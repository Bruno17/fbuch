<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd91eff4416eaf78422c77f0b4037441f',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/6361cd5d3bf3d98360d99ab3f8bf2ce0.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '954527a9eab294645332f148bf59a26f',
      'native_key' => NULL,
      'filename' => 'modCategory/708b34fd38f99901b99d932624d69c0e.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);