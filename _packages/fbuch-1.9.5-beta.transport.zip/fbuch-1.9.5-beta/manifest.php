<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c3de395c2090e6ef5929ade6d977e18d',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/80efa74b8d33786b2e5312c7c49c8c0d.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6afd8dc998ba85329a829c54fd6e1dc3',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/b9231fc25858ed5b559deea217903228.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0a7254802471098ad22d2d2432975c2b',
      'native_key' => NULL,
      'filename' => 'modCategory/9c174649d4432c02fab37d428cf61841.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9553d773b560ba8ebac0f6e811b8e381',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/bf09474bfff9e68218ebe31e68af6c6d.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8743b01ae019e2f85f8aebe5507ea0f2',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/52d30cbb414c0ee2fa7c0acf1b75861d.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ff0d175f0827590fdface38bcdcfeb99',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/91ff085fc7aa79d7f861a3ff01b20477.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ac1dfaf5ec0e8a65686de78ccf3c089c',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/b27924c079f8c398abf6b84b79918c7e.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5f8f3937320bde13606900e51882f331',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/4380b03e910416d6a523911f183ad572.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);