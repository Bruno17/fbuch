<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a46c8d0dd400b255558495ebdf19df7f',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/ae57037f33f0e3a2192ca6227a708411.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0112bc0c78125dd8688cf98ef44df797',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/b0352c6382079b4c3a91d66e4e2d82cd.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e8ad3b6223726a34ea7c9e220765b217',
      'native_key' => NULL,
      'filename' => 'modCategory/3c556906955d0fb51f082535cdeae62d.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '63d94141ad6e05d2c2e43c537c51d9b9',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/024630cb1a7d4a948af60a50dfa2d299.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e5106926a4e7d4a67cdb307de41d0674',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/5f108a520128612e4b04b9dea2cdf4c0.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9b7d4c12d694544add0a101ac2835659',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/d14f4c8a31835c73ca9e83db5352d5a4.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3c101d018ea167caa878926ef005bc3f',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/bc1b1ede7399676e0ac9f9fef689462f.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7b0824031d1c1a3c15d62ffe7fd103bf',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/5a0760263cf0284901f813a3e93c9615.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);