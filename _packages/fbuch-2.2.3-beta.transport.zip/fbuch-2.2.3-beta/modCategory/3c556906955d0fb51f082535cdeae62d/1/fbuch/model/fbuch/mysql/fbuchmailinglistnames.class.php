<?php
require_once (dirname(__DIR__) . '/fbuchmailinglistnames.class.php');
class fbuchMailinglistNames_mysql extends fbuchMailinglistNames {}