<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd472748551978488140348ca964ca0ec',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/2063d3b20c9264a80157ad952ce597d4.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31c939c80c92605d49264eef0a4cd156',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/57059051edcce86d97f8568260f1e99f.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a68795d4b359f5a411eff3012aa17659',
      'native_key' => NULL,
      'filename' => 'modCategory/94da8538201bb1ccbf1ef38dc44a191a.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c36a93ba1fa57b8c288f0a57caf88a19',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/5374d2710d9354f04881cb11e5bb4680.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '818c8260aa47abd73250e9f30040e8fb',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/d1ff04544e92d5ab9094b0af3a460106.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0f70ec9127487acbd9d6ddb1bab00c6a',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/d57a8206c64b3314fb82ca45e2a45593.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6311ad3b1568d5f4ec0a2c9266a20f13',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/257b93f9a2c7f3b9c3d2e1fd7218b400.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e1020fe730d6eaafbf2ddd2569259c2f',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/7e78f041cadbf4b799080f3622ea3826.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);