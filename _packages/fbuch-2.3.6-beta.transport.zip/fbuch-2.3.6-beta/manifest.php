<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '11328a55a50565db1a5e69997d96a80d',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/303ec89111009a320fcd4091690fc797.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49f7ec4f74ecb11d331e6fa5dd1c53ec',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/4760acdf06bc4586785927c61bd4319b.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a3600355426663232c163cd43fe94429',
      'native_key' => NULL,
      'filename' => 'modCategory/4c83a1af07714e6f1dd95aa49e2d99e6.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a36ce77e665bce822449def19ca4a3e7',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/920633a88e116fdec2a153ecec3ff81a.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6e7213eb2c10671d809918b98fecb32e',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/bcd464a35ff770b569953a16a72a3e75.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4b8b1fb098e2027261b35ce2a61aafe0',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/c9c3bd45f14a3105730518b959dac028.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd167552d6c3098f3a71b072afc9f2299',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/e9731f41e85ed500feb3bef774039544.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4863d62aff52f51486e79d7d98b5a986',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/c9a810595ec31fd9bc9d03ee0925224a.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);