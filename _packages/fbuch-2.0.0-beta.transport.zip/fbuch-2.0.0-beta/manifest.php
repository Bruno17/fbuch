<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '01c588354ba3a736d9b0a81212ef4bf9',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/367a6b99d8f0c1a1a39fa44924ab87db.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88f5da3a881efa9cec4dd938e0388b68',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/1e08c01417ee00f57468a44060081d5d.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5dd993bc924958cb74171c40751c4ac3',
      'native_key' => NULL,
      'filename' => 'modCategory/c232f63d5f696e9445edfeeacf66901d.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '05655ae5792f29378168f5baecbb0824',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/0fc90b56281eb7f87e9782708f15f2d0.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e0b09b69b8e1f2ef071d70365b92128a',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/a5b926a99c500dee428446d15710ad4a.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9e3d6c698276e47026ca2744d622d6c0',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/5ddb99ad2cc548281e43751d1817504a.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '92a8043bdc9e2ec18f9e92bb9fd95fee',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/c160c75fa9c1edc459685014cb53996d.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '136b107097c7ada3d17b070f23f22395',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/eafc26788264fc77cc3b061830ef8948.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);