<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchdate.class.php');
class fbuchDate_mysql extends fbuchDate {}