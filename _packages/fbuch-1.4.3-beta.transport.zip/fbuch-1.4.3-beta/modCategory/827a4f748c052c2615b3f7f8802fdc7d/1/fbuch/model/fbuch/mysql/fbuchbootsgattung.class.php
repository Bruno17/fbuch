<?php
require_once (dirname(dirname(__FILE__)) . '/fbuchbootsgattung.class.php');
class fbuchBootsGattung_mysql extends fbuchBootsGattung {}