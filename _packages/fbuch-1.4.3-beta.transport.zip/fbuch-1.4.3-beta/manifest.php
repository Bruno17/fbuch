<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'colorpicker' => '>=1.0.4',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1ecd0ac3c8d0d3477b187a76ef33ae47',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/797b5276d30f4d0b36bf3fd18c9e1a39.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7ed1dfa2e15dad366ba2237af60601e4',
      'native_key' => NULL,
      'filename' => 'modCategory/827a4f748c052c2615b3f7f8802fdc7d.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);