<?php
class mvMailLog extends xPDOSimpleObject {}