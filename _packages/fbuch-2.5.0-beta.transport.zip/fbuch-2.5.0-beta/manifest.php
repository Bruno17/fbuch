<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '516f7b9cec5f1893d8873727ad6807b2',
      'native_key' => 'fbuch',
      'filename' => 'modNamespace/30e5c536fc5b747ecb48c2fc7218cbd9.vehicle',
      'namespace' => 'fbuch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8185735a7c4a6ecf8bc2e8557a7471af',
      'native_key' => 'fbuch.endtime_offset',
      'filename' => 'modSystemSetting/ecfff1faaa0d9f86a805ba407fea02d2.vehicle',
      'namespace' => 'fbuch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4aa3fbdf50606925f8fa80dfb6e8e3a8',
      'native_key' => NULL,
      'filename' => 'modCategory/c3f18a328d5e19744b608bbd551ee0b5.vehicle',
      'namespace' => 'fbuch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '84a7ec84f62f96997cfafb77cf946b0a',
      'native_key' => 'Vereinsverwaltung',
      'filename' => 'modMenu/5f1d37afede26ec4247c041ea25ee980.vehicle',
      'namespace' => 'fbuch',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '546cc67bc296edad6b2b1143acb36df4',
      'native_key' => 'Fahrtenbuch/Termine',
      'filename' => 'modMenu/8b1e1a4f9b68f58f4f5b4ee209867060.vehicle',
      'namespace' => 'fbuch',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '763bac30c409826ed849c4eaffbb8538',
      'native_key' => 'Mitgliederverwaltung',
      'filename' => 'modMenu/6429b0e9a8d15510b4975cd2158444c8.vehicle',
      'namespace' => 'fbuch',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '580c9de07542fd11a7b1082bc42ab9f8',
      'native_key' => 'Individualisierungen',
      'filename' => 'modMenu/e29bcc65702aee56784f147ee7ecd53b.vehicle',
      'namespace' => 'fbuch',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '85b6e36a4ba519daf509b02e0804741c',
      'native_key' => 'Serienmails',
      'filename' => 'modMenu/fa43f0147f2972e2619d8d58adb367bf.vehicle',
      'namespace' => 'fbuch',
    ),
  ),
);